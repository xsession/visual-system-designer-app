# Renode external components overlay — implementation report

Date: 2026-07-12

## Scope

This overlay adds a catalog-driven Renode layer for **500 external components**:

- 100 display controllers/modules
- 300 sensors
- 100 actuators and actuator-driver ICs

The phrase “top” is treated as practical implementation priority across common embedded ecosystems, not audited worldwide sales ranking. The 400 sensor/actuator target is implemented as 300 sensors plus 100 actuators.

## Fidelity model

### Driver-compatible: 65

These entries map to dedicated C# behavior implementing common identification registers, commands, data paths, state transitions, framebuffers, outputs or interrupts used by typical firmware drivers.

- 15 display models/controller families
- 30 sensor models
- 20 actuator models/controller families

### Profiled behavioral: 435

These entries receive stable generated Renode classes backed by reusable I2C, SPI, UART or GPIO transaction models. They support deterministic input/state injection, IRQ/fault control, display framebuffer inspection or actuator state inspection, but exact vendor register compatibility is not claimed until refined and firmware-tested.

## Implemented runtime capabilities

- Renode `II2CPeripheral`, `ISPIPeripheral`, `IUART` and `IGPIOReceiver` integration
- register-pointer I2C transactions
- command/address SPI transactions
- UART host/device traffic
- GPIO input and output state
- IRQ and fault injection
- sensor sample channels with scaling and encoding
- display framebuffers, checksum and PPM export
- actuator command, enable, direction, position, velocity and fault state
- catalog search and `.repl` snippet generation
- source/header evidence scanner and refinement scaffold generation
- explicit address placeholder for strap-configurable I2C devices without a safe default

## Dedicated behavioral families

Representative display support includes SSD1306/SH1106, ST7735/ST7789/GC9A01, ILI9341/ILI9488, SSD1680/UC8151, HD44780, HT16K33, MAX7219, RA8875, FT800 and IS31FL3731.

Representative sensor support includes BME280/BMP280, SHT3x/SHT4x, MPU6050, LIS3DH, LSM6DSOX, BNO055, BH1750, TSL2591, APDS9960, VL53L0X, INA219/INA226, ADS1115, MCP9808, CCS811, SGP30, SCD4x, AS5600, MPR121, MAX30102, MLX90614, DS18B20, MAX31855/MAX31865, PMS5003, NEO-6M, HC-SR04 and HX711.

Representative actuator support includes PCA9685, TLC5940, WS2812B/APA102, L298N/TB6612FNG/DRV8833/DRV8871/DRV8313, A4988/DRV8825/TMC2209/TMC5160/L6470, hobby servos, DRV2605L, CS40L26, relays, ULN2003A and MCP4725.

## Validation performed

### Standalone overlay

- 10 tests passed
- exact catalog counts verified
- all 500 generated class names unique
- all 65 driver-compatible entries verified against dedicated generators
- all generated base classes verified against runtime implementations
- generation reproducibility verified
- C# brace-balance and duplicate generated-class checks passed
- refinement evidence extraction verified, including reset constants
- installer install/check/reinstall/remove and overwritten-file restoration passed

### Installed Renode-shaped tree

- 33 files installed
- installer check passed
- 8 installed-tree tests passed
- 2 standalone-installer tests skipped by design after installation
- CLI list, snippet, validation and refinement smoke tests passed
- clean removal restored the project file and removed the manifest and installed files

## Known boundary

A native Renode C# build was not possible in this execution environment because a complete recursive Renode checkout and .NET/Mono toolchain are unavailable. The implementation was therefore validated structurally and through its Python generation/integration suite, but `./build.sh` remains required in the real `custom-cores` checkout.

The models are transaction-level software models, not electrical or cycle-accurate simulations. The profiled tier does not claim exact vendor-driver compatibility. RF/optical propagation, analog noise and settling, display scan timing, physical motor mechanics, bus electrical faults and silicon errata require dedicated physics/co-simulation or further handwritten models.

## Recommended qualification

For each promoted device, use the general peripheral importer/refinement workflow with the current datasheet and vendor/RTOS driver sources, then run the unmodified driver or production firmware in Renode. Promote a profiled model to driver-compatible only after register, reset, command, IRQ and failure-path tests pass.
