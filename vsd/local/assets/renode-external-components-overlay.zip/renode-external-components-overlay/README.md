# Renode external component catalog

This overlay adds a catalog-driven external-device layer to Renode for commonly used displays, sensors and actuators.

## Coverage

- 100 display controllers and modules
- 300 sensors
- 100 actuators and driver ICs
- 500 generated Renode classes
- 65 high-priority driver-compatible behavioral models
- 435 profiled transaction-level models

The catalog is a practical implementation-priority list derived from devices that recur across Zephyr, CircuitPython, Arduino, SparkFun/Qwiic, maker and industrial firmware ecosystems. It is not presented as audited sales-volume data.

## Fidelity tiers

`driver_compatible` models implement key identification registers, commands, state transitions, data paths and interrupts used by common drivers.

`profiled_behavioral` models implement the correct external bus shape, injectable state, interrupts, faults, framebuffer or actuator state, but may not yet match every vendor-specific register and timing detail. Use the refinement importer with the datasheet and vendor source before claiming production-driver compatibility.

## Install

```bash
python3 apply_overlay.py /path/to/renode
python3 apply_overlay.py /path/to/renode --check
```

Then build Renode normally.

## Search the catalog

```bash
PYTHONPATH=tools python3 -m external_components list bme
PYTHONPATH=tools python3 -m external_components list --kind display ili
```

## Generate a platform snippet

```bash
PYTHONPATH=tools python3 -m external_components snippet bme280 \
  --kind sensor --name environment --parent i2c0
```

Output:

```text
environment: ExternalComponents.Generated.Sensor_BME280 @ i2c0 0x76
```

## Refine a profiled model from vendor sources

```bash
PYTHONPATH=tools python3 -m external_components refine bme688 \
  vendor_driver/include vendor_driver/src \
  --kind sensor --output build/refined/bme688
```

This produces an evidence report and a C# refinement scaffold. Detected constants remain evidence until register width, access, reset values, side effects and command sequencing are confirmed against the datasheet.

## Runtime inspection

Display models expose framebuffer dimensions, pixels, a checksum and PPM export. Sensor models expose sample injection and IRQ/fault control. Actuator models expose command, enabled, position, velocity and fault state where applicable.

See `docs/ARCHITECTURE.md`, `docs/COVERAGE.md` and `docs/CATALOG.csv`.
