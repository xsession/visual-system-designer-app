#!/usr/bin/env python3
"""Install the external display/sensor/actuator catalog into a Renode checkout."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

MARKER = "<!-- external-components-catalog -->"
COMPILE_INCLUDE = r"Peripherals\ExternalComponents\**\*.cs"
COMPILE_LINE = f'    <Compile Include="{COMPILE_INCLUDE}" /> {MARKER}'
MANIFEST = ".external-components-catalog.json"
BACKUP_DIR = ".external-components-backup"


def overlay_root() -> Path:
    return Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_repo(repo: Path) -> None:
    required = [repo / "src" / "Renode" / "Renode.csproj", repo / "platforms"]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise ValueError("not a Renode checkout; missing: " + ", ".join(missing))


def patch_project(project: Path) -> bool:
    text = project.read_text(encoding="utf-8-sig")
    if MARKER in text or COMPILE_INCLUDE in text:
        return False
    close = text.rfind("</Project>")
    if close < 0:
        raise ValueError(f"malformed project file: {project}")
    block = f"  <ItemGroup>\n{COMPILE_LINE}\n  </ItemGroup>\n"
    project.write_text(text[:close] + block + text[close:], encoding="utf-8")
    return True


def unpatch_project(project: Path) -> None:
    if not project.exists():
        return
    text = project.read_text(encoding="utf-8-sig")
    block = f"  <ItemGroup>\n{COMPILE_LINE}\n  </ItemGroup>\n"
    text = text.replace(block, "").replace(COMPILE_LINE + "\n", "").replace(COMPILE_LINE, "")
    project.write_text(text, encoding="utf-8")


def source_mapping() -> list[tuple[Path, Path]]:
    root = overlay_root()
    mappings: list[tuple[Path, Path]] = []
    for source in (root / "src" / "Renode" / "Peripherals" / "ExternalComponents").rglob("*.cs"):
        mappings.append((source, Path("src/Renode/Peripherals/ExternalComponents") / source.relative_to(root / "src" / "Renode" / "Peripherals" / "ExternalComponents")))
    for source in (root / "tools" / "external_components").rglob("*.py"):
        if "__pycache__" not in source.parts:
            mappings.append((source, Path("tools/external_components") / source.relative_to(root / "tools" / "external_components")))
    for source in (root / "catalog").glob("*.json"):
        mappings.append((source, Path("tools/external_components/catalog_data") / source.name))
    for source in (root / "docs").rglob("*"):
        if source.is_file():
            mappings.append((source, Path("docs/external_components") / source.relative_to(root / "docs")))
    mappings.append((root / "README.md", Path("docs/external_components/README.md")))
    mappings.append((root / "REVIEW_REPORT.md", Path("docs/external_components/REVIEW_REPORT.md")))
    for source in (root / "tests").rglob("*"):
        if source.is_file() and "__pycache__" not in source.parts and ".pytest_cache" not in source.parts:
            mappings.append((source, Path("tests/external_components") / source.relative_to(root / "tests")))
    return sorted(mappings, key=lambda item: str(item[1]))


def install(repo: Path) -> dict:
    validate_repo(repo)
    manifest_path = repo / MANIFEST
    previous = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
    previous_backups = set(previous.get("backups", []))
    backup_root = repo / BACKUP_DIR
    installed: list[dict] = []
    backups = set(previous_backups)

    for source, relative in source_mapping():
        target = repo / relative
        if target.exists() and relative.as_posix() not in previous.get("files_by_path", {}):
            backup = backup_root / relative
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, backup)
            backups.add(relative.as_posix())
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        installed.append({"path": relative.as_posix(), "sha256": sha256(target)})

    project = repo / "src" / "Renode" / "Renode.csproj"
    project_patched = patch_project(project) or previous.get("project_patched", False)
    manifest = {
        "version": 1,
        "files": installed,
        "files_by_path": {item["path"]: item["sha256"] for item in installed},
        "backups": sorted(backups),
        "project_patched": project_patched,
        "compile_include": COMPILE_INCLUDE,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return manifest


def check(repo: Path) -> list[str]:
    validate_repo(repo)
    manifest_path = repo / MANIFEST
    if not manifest_path.exists():
        return ["installation manifest is missing"]
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    issues: list[str] = []
    for item in manifest.get("files", []):
        path = repo / item["path"]
        if not path.exists():
            issues.append(f"missing installed file: {item['path']}")
        elif sha256(path) != item["sha256"]:
            issues.append(f"modified installed file: {item['path']}")
    project = repo / "src" / "Renode" / "Renode.csproj"
    if COMPILE_INCLUDE not in project.read_text(encoding="utf-8-sig"):
        issues.append("Renode.csproj does not compile external component sources")
    return issues


def remove(repo: Path) -> int:
    validate_repo(repo)
    manifest_path = repo / MANIFEST
    if not manifest_path.exists():
        return 0
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    removed = 0
    backup_root = repo / BACKUP_DIR
    backup_paths = set(manifest.get("backups", []))
    for item in manifest.get("files", []):
        relative = item["path"]
        target = repo / relative
        backup = backup_root / relative
        if relative in backup_paths and backup.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(backup, target)
            backup.unlink()
        elif target.exists():
            target.unlink()
            removed += 1
    unpatch_project(repo / "src" / "Renode" / "Renode.csproj")
    manifest_path.unlink(missing_ok=True)
    if backup_root.exists():
        for directory in sorted((p for p in backup_root.rglob("*") if p.is_dir()), reverse=True):
            try:
                directory.rmdir()
            except OSError:
                pass
        try:
            backup_root.rmdir()
        except OSError:
            pass
    return removed


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path)
    actions = parser.add_mutually_exclusive_group()
    actions.add_argument("--check", action="store_true")
    actions.add_argument("--remove", action="store_true")
    args = parser.parse_args(argv)
    repo = args.repo.resolve()
    try:
        if args.check:
            issues = check(repo)
            if issues:
                for issue in issues:
                    print(f"error: {issue}", file=sys.stderr)
                return 1
            print("External component catalog is installed correctly")
            return 0
        if args.remove:
            print(f"Removed {remove(repo)} external component files")
            return 0
        manifest = install(repo)
        print(f"Installed {len(manifest['files'])} external component files")
        return 0
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
