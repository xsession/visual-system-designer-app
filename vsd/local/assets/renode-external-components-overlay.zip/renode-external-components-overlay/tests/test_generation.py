import re

from external_components.generate import generate
from external_components.validate import validate
from support import ROOT


def test_generation_is_reproducible():
    generated = ROOT / "src/Renode/Peripherals/ExternalComponents/Generated"
    before = {p.name: p.read_text() for p in generated.glob("*.cs")}
    generate(ROOT)
    after = {p.name: p.read_text() for p in generated.glob("*.cs")}
    assert before == after


def test_all_generated_classes_and_static_structure():
    assert validate(ROOT) == []
    generated = ROOT / "src/Renode/Peripherals/ExternalComponents/Generated"
    text = "\n".join(p.read_text() for p in generated.glob("*.cs"))
    assert len(re.findall(r"public sealed class\s+", text)) == 500


def test_runtime_contains_bus_interfaces_and_state_hooks():
    runtime = "\n".join(p.read_text() for p in (ROOT / "src/Renode/Peripherals/ExternalComponents").glob("*.cs"))
    for token in ["II2CPeripheral", "ISPIPeripheral", "IUART", "IGPIOReceiver", "ExportPpm", "SetFault", "SetChannelValue"]:
        assert token in runtime
