from external_components.catalog import Catalog
from support import CATALOG_ROOT


def test_exact_counts_and_unique_classes():
    catalog = Catalog(CATALOG_ROOT)
    assert len(list(catalog.by_kind("display"))) == 100
    assert len(list(catalog.by_kind("sensor"))) == 300
    assert len(list(catalog.by_kind("actuator"))) == 100
    assert len(catalog.devices) == 500
    assert len({d.class_name for d in catalog.devices}) == 500


def test_priority_models_present():
    catalog = Catalog(CATALOG_ROOT)
    for kind, models in {
        "display": ["SSD1306", "ST7789", "ILI9341", "HD44780", "SSD1680"],
        "sensor": ["BME280", "SHT31", "MPU6050", "VL53L0X", "INA219", "MAX30102"],
        "actuator": ["PCA9685", "DRV2605L", "A4988", "TMC2209", "MCP4725"],
    }.items():
        for model in models:
            assert catalog.exact(model, kind).tier == "driver_compatible"


def test_selection_is_broad():
    catalog = Catalog(CATALOG_ROOT)
    sensor_categories = {d.raw["category"] for d in catalog.by_kind("sensor")}
    actuator_categories = {d.raw["category"] for d in catalog.by_kind("actuator")}
    display_families = {d.raw["family"] for d in catalog.by_kind("display")}
    assert len(sensor_categories) == 10
    assert len(actuator_categories) == 7
    assert len(display_families) >= 10
