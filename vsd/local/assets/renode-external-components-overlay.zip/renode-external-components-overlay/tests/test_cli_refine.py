from external_components.catalog import Catalog
from external_components.cli import make_snippet
from external_components.refine import collect_evidence, generate_refinement
from support import CATALOG_ROOT, FIXTURES


def test_snippet_generation():
    catalog = Catalog(CATALOG_ROOT)
    bme = catalog.exact("bme280", "sensor")
    assert make_snippet(bme, "environment", "i2c0", None) == "environment: ExternalComponents.Generated.Sensor_BME280 @ i2c0 0x76"
    display = catalog.exact("ili9341", "display")
    assert "@ spi0" in make_snippet(display, "lcd", "spi0", None)
    oled = catalog.exact("ssd1306", "display")
    assert make_snippet(oled, "oled", "i2c0", None).endswith("0x3C")
    address_required = catalog.exact("st7567", "display")
    assert "<address>" in make_snippet(address_required, "lcd2", "i2c0", None)


def test_source_refinement_scaffold(tmp_path):
    fixture = FIXTURES / "sample_bme_driver.h"
    evidence = collect_evidence([fixture])
    assert any(item.symbol == "BME280_REG_ID" and item.value == 0xD0 for item in evidence)
    device = Catalog(CATALOG_ROOT).exact("bme280", "sensor")
    manifest = generate_refinement(device, [fixture], tmp_path)
    assert manifest["register_count"] >= 4
    assert manifest["detected_addresses"] == [0x76]
    assert (tmp_path / "Refined_Sensor_BME280.cs").exists()
