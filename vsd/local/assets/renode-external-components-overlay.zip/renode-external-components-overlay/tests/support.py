from pathlib import Path

from external_components.catalog import default_catalog_root

TESTS_DIR = Path(__file__).resolve().parent
CANDIDATE = TESTS_DIR.parent
# Standalone overlay: <root>/tests. Installed Renode tree: <root>/tests/external_components.
ROOT = CANDIDATE if (CANDIDATE / "src").exists() and (CANDIDATE / "tools").exists() else CANDIDATE.parent
CATALOG_ROOT = default_catalog_root(ROOT)
FIXTURES = TESTS_DIR / "fixtures"
INSTALLER = ROOT / "apply_overlay.py"
