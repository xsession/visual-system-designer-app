from pathlib import Path
import json
import subprocess

import pytest

from support import INSTALLER

pytestmark = pytest.mark.skipif(not INSTALLER.exists(), reason="standalone overlay installer is not copied into Renode")


def make_repo(path: Path):
    (path / "src/Renode").mkdir(parents=True)
    (path / "platforms").mkdir()
    (path / "src/Renode/Renode.csproj").write_text('<Project Sdk="Microsoft.NET.Sdk">\n</Project>\n')


def run(*args):
    return subprocess.run(["python", str(INSTALLER), *map(str, args)], text=True, capture_output=True)


def test_install_check_idempotent_remove(tmp_path):
    make_repo(tmp_path)
    first = run(tmp_path)
    assert first.returncode == 0, first.stderr
    manifest = json.loads((tmp_path / ".external-components-catalog.json").read_text())
    assert len(manifest["files"]) >= 20
    assert run(tmp_path, "--check").returncode == 0
    second = run(tmp_path)
    assert second.returncode == 0
    assert run(tmp_path, "--check").returncode == 0
    assert run(tmp_path, "--remove").returncode == 0
    assert "ExternalComponents" not in (tmp_path / "src/Renode/Renode.csproj").read_text()
    assert not (tmp_path / ".external-components-catalog.json").exists()


def test_installer_restores_overwritten_file(tmp_path):
    make_repo(tmp_path)
    target = tmp_path / "docs/external_components/README.md"
    target.parent.mkdir(parents=True)
    target.write_text("original\n")
    assert run(tmp_path).returncode == 0
    assert target.read_text() != "original\n"
    assert run(tmp_path, "--remove").returncode == 0
    assert target.read_text() == "original\n"
