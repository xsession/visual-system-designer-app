# Coverage and fidelity

## Displays

The 100 display entries cover monochrome and grayscale OLED, monochrome LCD, memory LCD, e-paper, SPI/parallel TFT, AMOLED, embedded display engines, character LCD, LED matrix and segment display families.

Dedicated behavior includes command/data handling, address windows, framebuffer writes, reset/display state, e-paper busy signaling, character cells, LED RAM and PPM export.

## Sensors

The 300 sensor entries cover environmental, motion, magnetic, optical/ranging, air quality, electrical/power, position/force/touch, biomedical/thermal, industrial/weather and navigation/presence devices.

All sensor classes support deterministic values and faults. Dedicated models additionally expose key device IDs, measurement frames, common commands or well-known register layouts.

## Actuators

The 100 actuator entries cover LED drivers, DC/BLDC motor bridges, stepper drivers, servo controllers, haptics/audio, relays/fluid devices and analog-output devices.

Dedicated models include PCA9685 PWM channels, TLC5940 grayscale data, addressable LEDs, H-bridge state, step/dir position, TMC target state, hobby-servo position, DRV2605 effects, relay outputs and MCP4725 voltage.

## Accuracy boundary

The catalog does not imply cycle-accurate electrical simulation. Profiled models are intended for software integration, boot, command sequencing, error handling and deterministic scenario tests. Electrical noise, exact analog transfer functions, RF/optical physics, motor mechanics, display scan timing and silicon errata require dedicated models or co-simulation.
