# Architecture

The overlay is divided into four layers.

## Catalog

JSON records describe identity, vendor, priority, bus, default address, channels, geometry, fidelity and capabilities. The catalog is intentionally independent of C# so it can be regenerated, searched and extended automatically.

## Bus runtimes

The shared runtime implements:

- I2C register-pointer transactions
- SPI command/address transactions
- UART peripheral traffic
- GPIO trigger/state behavior
- IRQ and fault injection
- typed sensor channels
- display framebuffers and PPM export
- actuator command and state inspection

## Dedicated models

High-priority devices use explicit key-register or command behavior. Examples include SSD1306, ST77xx, ILI9341, HD44780, BME280, SHT3x, MPU6050, LIS3DH, VL53L0X, INA219, SCD4x, PCA9685, DRV2605, A4988 and TMC5160.

## Generated profile wrappers

Every catalog entry receives a stable Renode class. Profile wrappers choose an I2C, SPI, UART or GPIO runtime and define channels or geometry. These wrappers are useful for system tests immediately and are the starting point for source-assisted refinement.

## Source-assisted refinement

The refinement scanner reads vendor headers, HAL sources, examples, Zephyr bindings and text documentation. It records constants with file and line provenance and emits a model scaffold. It does not silently infer side effects when evidence is weak.
