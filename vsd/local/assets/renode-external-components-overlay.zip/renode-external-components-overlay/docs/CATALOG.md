# External component catalog

Total: **500**

- display: 100
- sensor: 300
- actuator: 100

## Fidelity

- driver_compatible: 65
- profiled_behavioral: 435

`driver_compatible` means key commands/registers are modeled for common drivers. `profiled_behavioral` means bus/state behavior is available but exact vendor-driver compatibility still needs importer evidence and firmware tests.
