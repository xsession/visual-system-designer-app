# Refining a component model

1. Select a catalog component.
2. Collect the current datasheet, register manual, vendor HAL/driver, example firmware and any Zephyr/Linux/CircuitPython driver.
3. Run the refinement scanner.
4. Review every detected address and register constant.
5. Add reset values, access modes, W1C/self-clear semantics, FIFO behavior, IRQ conditions and timing.
6. Add driver-level tests using unmodified vendor or RTOS firmware.
7. Promote the catalog tier only after those tests pass.

Example:

```bash
PYTHONPATH=tools python3 -m external_components refine vl53l1x \
  sources/st_vl53l1x_api zephyr/drivers/sensor/st/vl53l1x \
  --kind sensor --output build/refined/vl53l1x
```

The output includes `evidence.json` and a C# scaffold. The evidence file retains source paths and line numbers to make review repeatable.
