# Selection method

“Top” is interpreted as implementation priority rather than a claim of audited global sales ranking.

The list emphasizes devices that recur in:

- Zephyr drivers and devicetree bindings
- Adafruit CircuitPython libraries
- SparkFun/Qwiic libraries and modules
- Arduino libraries and common breakout boards
- vendor reference drivers and evaluation kits
- industrial control, robotics, environmental and biomedical prototypes

Controller variants are included separately when firmware identifies them differently or uses a different command/register protocol. Board-level aliases are included where they are widely used in firmware examples.
