from __future__ import annotations

import re
from pathlib import Path

from .catalog import Catalog, default_catalog_root
from .generate import ACTUATOR_DEDICATED, DISPLAY_DEDICATED, SENSOR_DEDICATED


def validate(root: Path) -> list[str]:
    errors: list[str] = []
    catalog = Catalog(default_catalog_root(root))
    expected = {"display": 100, "sensor": 300, "actuator": 100}
    for kind, count in expected.items():
        actual = len(list(catalog.by_kind(kind)))
        if actual != count:
            errors.append(f"{kind}: expected {count}, found {actual}")
    keys = [(d.kind, d.id) for d in catalog.devices]
    if len(keys) != len(set(keys)):
        errors.append("duplicate kind/id entries")
    classes = [d.class_name for d in catalog.devices]
    if len(classes) != len(set(classes)):
        errors.append("duplicate generated class names")
    for device in catalog.devices:
        if not device.bus:
            errors.append(f"{device.kind}:{device.id} has no bus")
        if device.tier not in {"driver_compatible", "profiled_behavioral"}:
            errors.append(f"{device.kind}:{device.id} has invalid tier {device.tier}")

    dedicated = {
        "display": set(DISPLAY_DEDICATED),
        "sensor": set(SENSOR_DEDICATED),
        "actuator": set(ACTUATOR_DEDICATED),
    }
    for kind in dedicated:
        expected_ids = {d.id for d in catalog.by_kind(kind) if d.tier == "driver_compatible"}
        missing_models = sorted(expected_ids - dedicated[kind])
        stale_models = sorted(dedicated[kind] - expected_ids)
        if missing_models:
            errors.append(f"{kind}: driver-compatible entries without dedicated generator: {', '.join(missing_models)}")
        if stale_models:
            errors.append(f"{kind}: dedicated generator entries not marked driver-compatible: {', '.join(stale_models)}")

    source_root = root / "src" / "Renode" / "Peripherals" / "ExternalComponents"
    generated = source_root / "Generated"
    generated_text = "\n".join(p.read_text(encoding="utf-8") for p in generated.glob("*.cs"))
    declared_generated = set(re.findall(r"public sealed class\s+(\w+)", generated_text))
    missing = sorted(set(classes) - declared_generated)
    extra = sorted(declared_generated - set(classes))
    if missing:
        errors.append(f"missing generated classes: {', '.join(missing[:10])}")
    if extra:
        errors.append(f"unexpected generated classes: {', '.join(extra[:10])}")

    runtime_text = "\n".join(
        path.read_text(encoding="utf-8")
        for path in source_root.glob("*.cs")
    )
    runtime_classes = set(re.findall(r"public\s+(?:abstract\s+|sealed\s+)?class\s+(\w+)", runtime_text))
    inherited_bases = set(re.findall(r"public sealed class\s+\w+\s*:\s*(\w+)", generated_text))
    missing_bases = sorted(inherited_bases - runtime_classes)
    if missing_bases:
        errors.append(f"generated classes reference missing runtime bases: {', '.join(missing_bases)}")

    for path in source_root.rglob("*.cs"):
        source = path.read_text(encoding="utf-8")
        if source.count("{") != source.count("}"):
            errors.append(f"brace mismatch: {path.relative_to(root)}")
    return errors
