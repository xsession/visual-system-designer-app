from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class CatalogDevice:
    kind: str
    id: str
    model: str
    class_name: str
    vendor: str
    tier: str
    bus: tuple[str, ...]
    raw: dict

    @property
    def type_name(self) -> str:
        return f"ExternalComponents.Generated.{self.class_name}"


class Catalog:
    def __init__(self, root: Path):
        self.root = root
        self.devices = self._load()

    @classmethod
    def from_overlay(cls) -> "Catalog":
        return cls(default_catalog_root())

    def _load(self) -> list[CatalogDevice]:
        result: list[CatalogDevice] = []
        for kind in ("displays", "sensors", "actuators"):
            path = self.root / f"{kind}.json"
            data = json.loads(path.read_text(encoding="utf-8"))
            for entry in data["devices"]:
                result.append(
                    CatalogDevice(
                        kind=entry["kind"],
                        id=entry["id"],
                        model=entry["model"],
                        class_name=entry["class_name"],
                        vendor=entry["vendor"],
                        tier=entry["tier"],
                        bus=tuple(entry.get("bus", [])),
                        raw=entry,
                    )
                )
        return result

    def find(self, query: str, kind: str | None = None) -> list[CatalogDevice]:
        needle = query.casefold()
        return [
            d for d in self.devices
            if (kind is None or d.kind == kind)
            and (needle in d.id.casefold() or needle in d.model.casefold() or needle in d.vendor.casefold())
        ]

    def exact(self, identifier: str, kind: str | None = None) -> CatalogDevice:
        key = identifier.casefold()
        matches = [
            d for d in self.devices
            if (kind is None or d.kind == kind)
            and (d.id.casefold() == key or d.model.casefold() == key or d.class_name.casefold() == key)
        ]
        if not matches:
            raise KeyError(f"component not found: {identifier}")
        if len(matches) > 1:
            kinds = ", ".join(sorted({m.kind for m in matches}))
            raise KeyError(f"ambiguous component {identifier!r}; specify --kind ({kinds})")
        return matches[0]

    def by_kind(self, kind: str) -> Iterable[CatalogDevice]:
        return (d for d in self.devices if d.kind == kind)


def default_catalog_root(root: Path | None = None) -> Path:
    candidates = []
    if root is not None:
        candidates.append(root / "catalog")
    package = Path(__file__).resolve().parent
    candidates.extend([package / "catalog_data", package.parents[1] / "catalog", package.parents[2] / "catalog"])
    for candidate in candidates:
        if (candidate / "displays.json").exists():
            return candidate
    raise FileNotFoundError("external component catalog not found")
