from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .catalog import Catalog, default_catalog_root
from .generate import generate
from .validate import validate
from .refine import generate_refinement


def make_snippet(device, name: str, parent: str | None, address: str | None) -> str:
    bus = device.bus[0] if device.bus else "none"
    if bus == "i2c":
        if parent is None:
            parent = "i2c0"
        if address is not None:
            addr = address
            note = ""
        elif device.raw.get("default_address") is not None:
            addr = f"0x{device.raw['default_address']:02X}"
            note = ""
        else:
            addr = "<address>"
            note = "\n# Select the address from the module strap/configuration and replace <address>."
        return f"{name}: {device.type_name} @ {parent} {addr}{note}"
    if bus == "spi":
        return f"{name}: {device.type_name} @ {parent or 'spi0'}"
    return f"{name}: {device.type_name}\n# Connect its {bus} signals explicitly in your platform description."


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Search and generate Renode external component snippets")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    sub = parser.add_subparsers(dest="command", required=True)
    p_list = sub.add_parser("list")
    p_list.add_argument("query", nargs="?", default="")
    p_list.add_argument("--kind", choices=["display", "sensor", "actuator"])
    p_list.add_argument("--json", action="store_true")
    p_snip = sub.add_parser("snippet")
    p_snip.add_argument("component")
    p_snip.add_argument("--kind", choices=["display", "sensor", "actuator"])
    p_snip.add_argument("--name", default="component")
    p_snip.add_argument("--parent")
    p_snip.add_argument("--address")
    sub.add_parser("generate")
    sub.add_parser("validate")
    p_refine = sub.add_parser("refine")
    p_refine.add_argument("component")
    p_refine.add_argument("sources", nargs="+", type=Path)
    p_refine.add_argument("--kind", choices=["display", "sensor", "actuator"])
    p_refine.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    catalog = Catalog(default_catalog_root(args.root))
    if args.command == "list":
        matches = catalog.find(args.query, args.kind)
        if args.json:
            print(json.dumps([d.raw for d in matches], indent=2))
        else:
            for d in matches:
                print(f"{d.kind:8} {d.id:28} {d.tier:20} {'+'.join(d.bus):16} {d.vendor} {d.model}")
        return 0
    if args.command == "snippet":
        try:
            device = catalog.exact(args.component, args.kind)
        except KeyError as error:
            print(f"error: {error}", file=sys.stderr)
            return 2
        print(make_snippet(device, args.name, args.parent, args.address))
        return 0
    if args.command == "generate":
        generate(args.root)
        return 0
    if args.command == "refine":
        try:
            device = catalog.exact(args.component, args.kind)
        except KeyError as error:
            print(f"error: {error}", file=sys.stderr)
            return 2
        manifest = generate_refinement(device, args.sources, args.output)
        print(f"wrote {manifest['register_count']} register/command evidence entries to {args.output}")
        return 0
    errors = validate(args.root)
    if errors:
        for error in errors:
            print(f"error: {error}", file=sys.stderr)
        return 1
    print("external component catalog is valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
