from __future__ import annotations

import csv
import json
import re
from pathlib import Path

from .catalog import Catalog, CatalogDevice, default_catalog_root

DISPLAY_DEDICATED = {
    "ssd1306": ("SSD1306Controller", '"SSD1306", "Solomon Systech", 128, 64'),
    "sh1106": ("SSD1306Controller", '"SH1106", "Sino Wealth", 128, 64'),
    "st7735": ("ST77xxController", '"ST7735", "Sitronix", 128, 160, 16'),
    "st7789": ("ST77xxController", '"ST7789", "Sitronix", 240, 240, 16'),
    "ili9341": ("ILI9341Controller", '"ILI9341", "Ilitek", 240, 320, 16'),
    "ili9488": ("ILI9341Controller", '"ILI9488", "Ilitek", 320, 480, 18'),
    "gc9a01": ("ST77xxController", '"GC9A01", "GalaxyCore", 240, 240, 16'),
    "ssd1680": ("EpaperController", '"SSD1680", "Solomon Systech", 250, 122'),
    "uc8151": ("EpaperController", '"UC8151", "UltraChip", 296, 128'),
    "hd44780": ("CharacterDisplayController", '"HD44780", "Hitachi", 20, 4, "driver_compatible"'),
    "ht16k33": ("HT16K33Controller", '"HT16K33", "Holtek"'),
    "max7219": ("MAX7219Controller", '"MAX7219", "Analog Devices"'),
    "ra8875": ("RA8875Controller", '"RA8875", "RAiO", 800, 480'),
    "ft800": ("FT8xxController", '"FT800", "Bridgetek", 512, 512'),
    "is31fl3731": ("IS31FL3731Controller", '"IS31FL3731", "Lumissil"'),
}

SENSOR_DEDICATED = {
    "bme280": "BoschBME280", "bmp280": "BoschBMP280", "sht31": "SensirionSHT3x", "sht40": "SensirionSHT4x",
    "mpu6050": "InvenSenseMPU6050", "lis3dh": "STLIS3DH", "lsm6dsox": "STLSM6DSOX", "bno055": "BoschBNO055",
    "bh1750": "RohmBH1750", "tsl2591": "AMS_TSL2591", "apds9960": "BroadcomAPDS9960", "vl53l0x": "STVL53L0X",
    "ina219": "TI_INA219", "ina226": "TI_INA226", "ads1115": "TI_ADS1115", "mcp9808": "MicrochipMCP9808",
    "ccs811": "AMS_CCS811", "sgp30": "SensirionSGP30", "scd41": "SensirionSCD4x", "as5600": "AMS_AS5600",
    "mpr121": "NXP_MPR121", "max30102": "MaximMAX30102", "mlx90614": "MelexisMLX90614", "ds18b20": "DS18B20Sensor",
    "max31855": "MaximMAX31855", "pms5003": "PlantowerPMS5003", "hc_sr04": "HCSR04Sensor", "neo6m": "UBloxNEO6M",
    "hx711": "HX711Sensor", "max31865": "MaximMAX31865",
}

ACTUATOR_DEDICATED = {
    "pca9685": ("PCA9685Controller", '"PCA9685", "NXP"'),
    "tlc5940": ("TLC5940Controller", '"TLC5940", "Texas Instruments"'),
    "ws2812b": ("AddressableLEDStrip", '"WS2812B", "Worldsemi", 16'),
    "apa102": ("AddressableLEDStrip", '"APA102", "Newstar", 16'),
    "l298n": ("HBridgeMotorDriver", '"L298N", "STMicroelectronics"'),
    "tb6612fng": ("HBridgeMotorDriver", '"TB6612FNG", "Toshiba"'),
    "drv8833": ("HBridgeMotorDriver", '"DRV8833", "Texas Instruments"'),
    "drv8871": ("HBridgeMotorDriver", '"DRV8871", "Texas Instruments"'),
    "drv8313": ("HBridgeMotorDriver", '"DRV8313", "Texas Instruments"'),
    "a4988": ("StepDirDriver", '"A4988", "Allegro"'),
    "drv8825": ("StepDirDriver", '"DRV8825", "Texas Instruments"'),
    "tmc2209": ("StepDirDriver", '"TMC2209", "Trinamic"'),
    "tmc5160": ("TMCStepperController", '"TMC5160", "Trinamic"'),
    "l6470": ("TMCStepperController", '"L6470", "STMicroelectronics"'),
    "hobby_servo_generic": ("HobbyServoActuator", '"HOBBY_SERVO_GENERIC", "Various"'),
    "drv2605l": ("DRV2605Controller", '"DRV2605L", "Texas Instruments"'),
    "cs40l26": ("CirrusHapticController", '"CS40L26", "Cirrus Logic"'),
    "relay_1ch": ("RelayActuator", '"RELAY_1CH", "Various", 1'),
    "uln2003a": ("ULN2003Controller", '"ULN2003A", "Texas Instruments"'),
    "mcp4725": ("MCP4725Controller", '"MCP4725", "Microchip"'),
}


def q(value: str) -> str:
    return json.dumps(value)


def display_class(device: CatalogDevice) -> str:
    raw = device.raw
    if device.id in DISPLAY_DEDICATED:
        base, args = DISPLAY_DEDICATED[device.id]
        return f"    public sealed class {device.class_name} : {base}\n    {{\n        public {device.class_name}() : base({args}) {{ }}\n    }}\n"
    geometry = raw["geometry"]
    bus = raw["bus"][0]
    family = raw["family"]
    if family == "character_lcd":
        base = "CharacterDisplayController"
        args = f'{q(device.model)}, {q(device.vendor)}, {geometry["width"]}, {geometry["height"]}, {q(device.tier)}'
    elif bus == "i2c":
        base = "GenericI2CDisplay"
        args = f'{q(device.model)}, {q(device.vendor)}, {geometry["width"]}, {geometry["height"]}, {geometry["bits_per_pixel"]}, {q(device.tier)}'
    elif bus in {"spi", "qspi"}:
        base = "GenericSPIDisplay"
        args = f'{q(device.model)}, {q(device.vendor)}, {geometry["width"]}, {geometry["height"]}, {geometry["bits_per_pixel"]}, {q(device.tier)}'
    else:
        base = "GenericParallelDisplay"
        args = f'{q(device.model)}, {q(device.vendor)}, {geometry["width"]}, {geometry["height"]}, {geometry["bits_per_pixel"]}, {q(device.tier)}'
    return f"    public sealed class {device.class_name} : {base}\n    {{\n        public {device.class_name}() : base({args}) {{ }}\n    }}\n"


def sensor_class(device: CatalogDevice) -> str:
    if device.id in SENSOR_DEDICATED:
        base = SENSOR_DEDICATED[device.id]
        return f"    public sealed class {device.class_name} : {base}\n    {{\n        public {device.class_name}() : base({q(device.model)}, {q(device.vendor)}) {{ }}\n    }}\n"
    buses = set(device.bus)
    if "i2c" in buses:
        base = "ProfiledI2CSensor"
    elif "spi" in buses:
        base = "ProfiledSPISensor"
    elif "uart" in buses or "uart_i2c" in buses:
        base = "ProfiledUARTSensor"
    else:
        base = "ProfiledGPIOSensor"
    lines = [f"    public sealed class {device.class_name} : {base}", "    {", f"        public {device.class_name}() : base({q(device.model)}, {q(device.vendor)}, {q(device.tier)})", "        {"]
    if base in {"ProfiledI2CSensor", "ProfiledSPISensor"}:
        register = 0x10
        for channel in device.raw.get("channels", []):
            lines.append(f"            DefineChannel({q(channel['name'])}, {q(channel['unit'])}, {channel['resolution']!r}, 0x{register:02X}, 2, true, true);")
            lines.append(f"            SetChannelValue({q(channel['name'])}, 0);")
            register += 2
    elif base == "ProfiledUARTSensor":
        for channel in device.raw.get("channels", []):
            lines.append(f"            SetChannelValue({q(channel['name'])}, 0);")
    else:
        lines.append("            Threshold = 0.5;")
    lines += ["        }", "    }", ""]
    return "\n".join(lines)


def actuator_class(device: CatalogDevice) -> str:
    if device.id in ACTUATOR_DEDICATED:
        base, args = ACTUATOR_DEDICATED[device.id]
        return f"    public sealed class {device.class_name} : {base}\n    {{\n        public {device.class_name}() : base({args}) {{ }}\n    }}\n"
    buses = set(device.bus)
    if "i2c" in buses:
        base = "ProfiledI2CActuator"
    elif "spi" in buses:
        base = "ProfiledSPIActuator"
    elif "uart" in buses:
        base = "ProfiledUARTActuator"
    else:
        base = "ProfiledGPIOActuator"
    return f"    public sealed class {device.class_name} : {base}\n    {{\n        public {device.class_name}() : base({q(device.model)}, {q(device.vendor)}, {q(device.tier)}) {{ }}\n    }}\n"


def generate(root: Path) -> None:
    catalog = Catalog(default_catalog_root(root))
    out = root / "src" / "Renode" / "Peripherals" / "ExternalComponents" / "Generated"
    out.mkdir(parents=True, exist_ok=True)
    headers = {
        "display": "using Antmicro.Renode.Peripherals.ExternalComponents.Displays;",
        "sensor": "using Antmicro.Renode.Peripherals.ExternalComponents.Sensors;",
        "actuator": "using Antmicro.Renode.Peripherals.ExternalComponents.Actuators;",
    }
    builders = {"display": display_class, "sensor": sensor_class, "actuator": actuator_class}
    filenames = {"display": "DisplayCatalog.Generated.cs", "sensor": "SensorCatalog.Generated.cs", "actuator": "ActuatorCatalog.Generated.cs"}
    for kind in ("display", "sensor", "actuator"):
        parts = ["// Generated by tools/external_components/generate.py", "// SPDX-License-Identifier: MIT", "", headers[kind], "", "namespace Antmicro.Renode.Peripherals.ExternalComponents.Generated", "{"]
        for device in catalog.by_kind(kind):
            parts.append(builders[kind](device))
        parts.append("}")
        (out / filenames[kind]).write_text("\n".join(parts) + "\n", encoding="utf-8")

    docs = root / "docs"
    docs.mkdir(exist_ok=True)
    with (docs / "CATALOG.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["kind", "rank", "id", "model", "vendor", "tier", "bus", "class"])
        for device in catalog.devices:
            writer.writerow([device.kind, device.raw["rank"], device.id, device.model, device.vendor, device.tier, "+".join(device.bus), device.type_name])

    counts = {kind: len(list(catalog.by_kind(kind))) for kind in ("display", "sensor", "actuator")}
    tier_counts: dict[str, int] = {}
    for d in catalog.devices:
        tier_counts[d.tier] = tier_counts.get(d.tier, 0) + 1
    report = ["# External component catalog", "", f"Total: **{len(catalog.devices)}**", ""]
    report += [f"- {kind}: {count}" for kind, count in counts.items()]
    report += ["", "## Fidelity", ""] + [f"- {tier}: {count}" for tier, count in sorted(tier_counts.items())]
    report += ["", "`driver_compatible` means key commands/registers are modeled for common drivers. `profiled_behavioral` means bus/state behavior is available but exact vendor-driver compatibility still needs importer evidence and firmware tests.", ""]
    (docs / "CATALOG.md").write_text("\n".join(report), encoding="utf-8")


if __name__ == "__main__":
    generate(Path(__file__).resolve().parents[2])
