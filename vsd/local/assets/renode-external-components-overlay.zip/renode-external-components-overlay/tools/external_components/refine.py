from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

from .catalog import CatalogDevice

REGISTER_PATTERNS = [
    re.compile(r"^\s*#\s*define\s+([A-Z][A-Z0-9_]*(?:REG|REGISTER|STATUS|CTRL|CONFIG|DATA|ID|CMD|RESET)[A-Z0-9_]*)\s+\(?\s*(0x[0-9A-Fa-f]+|\d+)"),
    re.compile(r"^\s*(?:static\s+)?(?:const\s+)?(?:u?int(?:8|16|32)_t|byte|int|long)\s+([A-Za-z][A-Za-z0-9_]*(?:Reg|Register|Status|Control|Config|Data|Id|Command)[A-Za-z0-9_]*)\s*=\s*(0x[0-9A-Fa-f]+|\d+)"),
    re.compile(r"^\s*([A-Z][A-Z0-9_]{2,})\s*=\s*(0x[0-9A-Fa-f]+|\d+)\s*[,;]"),
]
ADDRESS_PATTERN = re.compile(r"(?:I2C|SLAVE|DEVICE)?_?ADDR(?:ESS)?\w*\s*(?:=|\s)\s*(0x[0-9A-Fa-f]+|\d+)", re.IGNORECASE)
RESET_PATTERN = re.compile(r"RESET\w*\s*(?:=|\s)\s*(0x[0-9A-Fa-f]+|\d+)", re.IGNORECASE)


@dataclass(frozen=True)
class Evidence:
    symbol: str
    value: int
    source: str
    line: int
    kind: str


def iter_source_files(paths: Iterable[Path]) -> Iterable[Path]:
    extensions = {".h", ".hpp", ".c", ".cc", ".cpp", ".py", ".rs", ".yaml", ".yml", ".dts", ".overlay", ".txt", ".md"}
    for path in paths:
        if path.is_file() and path.suffix.lower() in extensions:
            yield path
        elif path.is_dir():
            for item in path.rglob("*"):
                if item.is_file() and item.suffix.lower() in extensions:
                    yield item


def collect_evidence(paths: Iterable[Path]) -> list[Evidence]:
    result: list[Evidence] = []
    seen: set[tuple[str, int, str]] = set()
    for path in iter_source_files(paths):
        try:
            lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        except OSError:
            continue
        for line_number, line in enumerate(lines, 1):
            for pattern in REGISTER_PATTERNS:
                match = pattern.search(line)
                if match:
                    symbol, value_text = match.groups()
                    value = int(value_text, 0)
                    key = (symbol, value, str(path))
                    if key not in seen:
                        result.append(Evidence(symbol, value, str(path), line_number, "register_or_command"))
                        seen.add(key)
                    break
            for match in ADDRESS_PATTERN.finditer(line):
                value = int(match.group(1), 0)
                key = ("I2C_ADDRESS", value, str(path))
                if key not in seen:
                    result.append(Evidence("I2C_ADDRESS", value, str(path), line_number, "address"))
                    seen.add(key)
    return result


def generate_refinement(device: CatalogDevice, sources: list[Path], output: Path) -> dict:
    evidence = collect_evidence(sources)
    output.mkdir(parents=True, exist_ok=True)
    addresses = sorted({e.value for e in evidence if e.kind == "address" and 0 <= e.value <= 0x7F})
    registers = sorted((e for e in evidence if e.kind == "register_or_command" and 0 <= e.value <= 0xFFFF), key=lambda e: (e.value, e.symbol))
    manifest = {
        "component": device.raw,
        "source_paths": [str(p) for p in sources],
        "detected_addresses": addresses,
        "evidence": [asdict(e) for e in evidence],
        "register_count": len(registers),
        "status": "needs_review",
        "notes": [
            "Detected constants are evidence, not automatically trusted semantics.",
            "Confirm access mode, reset value, width, side effects and command sequencing against the datasheet.",
        ],
    }
    (output / "evidence.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    base = "ProfiledI2CSensor" if device.kind == "sensor" else "ProfiledI2CActuator" if device.kind == "actuator" else "GenericI2CDisplay"
    if "spi" in device.bus and "i2c" not in device.bus:
        base = "ProfiledSPISensor" if device.kind == "sensor" else "ProfiledSPIActuator" if device.kind == "actuator" else "GenericSPIDisplay"
    namespace = "Antmicro.Renode.Peripherals.ExternalComponents.Refined"
    class_name = f"Refined_{device.class_name}"
    lines = [
        "// Generated refinement scaffold; review before use.",
        "// SPDX-License-Identifier: MIT",
        "",
        "using Antmicro.Renode.Peripherals.ExternalComponents.Sensors;",
        "using Antmicro.Renode.Peripherals.ExternalComponents.Actuators;",
        "using Antmicro.Renode.Peripherals.ExternalComponents.Displays;",
        "",
        f"namespace {namespace}",
        "{",
    ]
    if device.kind == "display":
        geometry = device.raw.get("geometry", {"width": 1, "height": 1, "bits_per_pixel": 1})
        ctor = f'base("{device.model}", "{device.vendor}", {geometry["width"]}, {geometry["height"]}, {geometry["bits_per_pixel"]}, "refined_scaffold")'
    else:
        ctor = f'base("{device.model}", "{device.vendor}", "refined_scaffold")'
    lines += [f"    public class {class_name} : {base}", "    {", f"        public {class_name}() : {ctor}", "        {"]
    for evidence_item in registers[:128]:
        safe = re.sub(r"[^A-Za-z0-9_]", "_", evidence_item.symbol)
        if safe and safe[0].isdigit():
            safe = "R_" + safe
        lines.append(f"            // {safe} = 0x{evidence_item.value:X}; {Path(evidence_item.source).name}:{evidence_item.line}")
    lines += ["        }", "    }", "}", ""]
    (output / f"{class_name}.cs").write_text("\n".join(lines), encoding="utf-8")
    return manifest
