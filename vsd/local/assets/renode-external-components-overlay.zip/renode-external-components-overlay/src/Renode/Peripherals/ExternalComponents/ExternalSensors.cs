// Copyright (c) 2026
// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using System.Globalization;

using Antmicro.Renode.Core;
using Antmicro.Renode.Peripherals.I2C;
using Antmicro.Renode.Peripherals.SPI;

namespace Antmicro.Renode.Peripherals.ExternalComponents.Sensors
{
    public class ProfiledI2CSensor : ProfiledI2CDevice
    {
        public ProfiledI2CSensor(string model, string vendor, string fidelity = "profiled_behavioral") : base(model, vendor, fidelity, 512)
        {
            WriteRegister(0, (byte)(ExternalComponentEncoding.Fnv1a(System.Text.Encoding.ASCII.GetBytes(model)) >> 8));
            WriteRegister(1, (byte)ExternalComponentEncoding.Fnv1a(System.Text.Encoding.ASCII.GetBytes(model)));
        }

        public void DefineChannel(string name, string unit, double resolution, int registerOffset, int width = 2, bool signed = true, bool bigEndian = true)
        {
            channels[name] = new SensorChannel(name, unit, resolution, registerOffset, width, signed, bigEndian);
            values[name] = 0;
        }

        public void SetChannelValue(string name, double value)
        {
            if(!channels.TryGetValue(name, out var channel))
            {
                throw new ArgumentException($"Unknown channel: {name}", nameof(name));
            }
            values[name] = value;
            ExternalComponentEncoding.Encode(Registers, channel, value);
            IRQ.Set();
        }

        public double GetChannelValue(string name)
        {
            return values.TryGetValue(name, out var value) ? value : 0;
        }

        public string[] GetChannels()
        {
            var result = new string[channels.Count];
            channels.Keys.CopyTo(result, 0);
            return result;
        }

        public void ClearDataReady()
        {
            IRQ.Unset();
        }

        public override void Reset()
        {
            base.Reset();
            foreach(var key in new List<string>(values.Keys)) values[key] = 0;
        }

        private readonly Dictionary<string, SensorChannel> channels = new Dictionary<string, SensorChannel>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, double> values = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
    }

    public class ProfiledSPISensor : ProfiledSPIDevice
    {
        public ProfiledSPISensor(string model, string vendor, string fidelity = "profiled_behavioral") : base(model, vendor, fidelity, 512)
        {
            WriteRegister(0, (byte)(ExternalComponentEncoding.Fnv1a(System.Text.Encoding.ASCII.GetBytes(model)) >> 8));
            WriteRegister(1, (byte)ExternalComponentEncoding.Fnv1a(System.Text.Encoding.ASCII.GetBytes(model)));
        }

        public void DefineChannel(string name, string unit, double resolution, int registerOffset, int width = 2, bool signed = true, bool bigEndian = true)
        {
            channels[name] = new SensorChannel(name, unit, resolution, registerOffset, width, signed, bigEndian);
            values[name] = 0;
        }

        public void SetChannelValue(string name, double value)
        {
            if(!channels.TryGetValue(name, out var channel)) throw new ArgumentException($"Unknown channel: {name}");
            values[name] = value;
            var bytes = new byte[512];
            for(var i = 0; i < bytes.Length; i++) bytes[i] = ReadRegister(i);
            ExternalComponentEncoding.Encode(bytes, channel, value);
            for(var i = 0; i < channel.Width; i++) WriteRegister(channel.RegisterOffset + i, bytes[channel.RegisterOffset + i]);
            IRQ.Set();
        }

        public double GetChannelValue(string name) => values.TryGetValue(name, out var value) ? value : 0;

        private readonly Dictionary<string, SensorChannel> channels = new Dictionary<string, SensorChannel>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, double> values = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
    }

    public class ProfiledUARTSensor : ProfiledUARTDevice
    {
        public ProfiledUARTSensor(string model, string vendor, string fidelity = "profiled_behavioral", uint baudRate = 9600) : base(model, vendor, fidelity, baudRate)
        {
        }

        public void SetChannelValue(string name, double value)
        {
            values[name] = value;
        }

        public double GetChannelValue(string name) => values.TryGetValue(name, out var value) ? value : 0;

        public void EmitCsvFrame()
        {
            var fields = new List<string>();
            foreach(var item in values)
            {
                fields.Add(item.Key + "=" + item.Value.ToString("0.###", CultureInfo.InvariantCulture));
            }
            EmitText(string.Join(",", fields) + "\r\n");
        }

        private readonly Dictionary<string, double> values = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
    }

    public class ProfiledGPIOSensor : ProfiledGPIODevice
    {
        public ProfiledGPIOSensor(string model, string vendor, string fidelity = "profiled_behavioral") : base(model, vendor, fidelity, 4)
        {
        }

        public void SetValue(double value)
        {
            Value = value;
            Output.Set(value > Threshold);
            IRQ.Set();
        }

        public double Value { get; private set; }
        public double Threshold { get; set; }
    }

    public class BoschBME280 : ProfiledI2CSensor
    {
        public BoschBME280(string model = "BME280", string vendor = "Bosch") : base(model, vendor, "driver_compatible")
        {
            DefineChannel("temperature", "C", 0.01, 0xFA, 3, true, true);
            DefineChannel("pressure", "Pa", 1.0, 0xF7, 3, false, true);
            DefineChannel("humidity", "percent", 0.01, 0xFD, 2, false, true);
            WriteRegister(0xD0, 0x60);
            WriteRegister(0xF3, 0x00);
            // Stable non-zero calibration values used by common drivers.
            var calibration = new byte[] {0x70,0x6B,0x43,0x67,0x18,0xFC,0x7D,0x8E,0x43,0xD6,0xD0,0x0B,0x27,0x0B,0x8C,0x00,0xF9,0xFF,0x8C,0x3C,0xF8,0xC6,0x70,0x17};
            for(var i = 0; i < calibration.Length; i++) WriteRegister(0x88 + i, calibration[i]);
            SetEnvironment(25.0, 101325, 50.0);
        }

        public void SetEnvironment(double temperature, double pressure, double humidity)
        {
            // Raw values are deliberately deterministic and monotonic; calibration math remains exercised by firmware.
            var rawT = (uint)Math.Max(0, Math.Min(0xFFFFF, 519888 + (temperature - 25.0) * 1000));
            var rawP = (uint)Math.Max(0, Math.Min(0xFFFFF, 415148 + (101325.0 - pressure) * 2));
            var rawH = (ushort)Math.Max(0, Math.Min(65535, humidity * 655.35));
            WriteRegister(0xF7, (byte)(rawP >> 12)); WriteRegister(0xF8, (byte)(rawP >> 4)); WriteRegister(0xF9, (byte)(rawP << 4));
            WriteRegister(0xFA, (byte)(rawT >> 12)); WriteRegister(0xFB, (byte)(rawT >> 4)); WriteRegister(0xFC, (byte)(rawT << 4));
            WriteRegister16(0xFD, rawH, true);
            IRQ.Set();
        }
    }

    public class BoschBMP280 : BoschBME280
    {
        public BoschBMP280(string model = "BMP280", string vendor = "Bosch") : base(model, vendor)
        {
            WriteRegister(0xD0, 0x58);
        }
    }

    public class SensirionSHT3x : ExternalComponentBase, II2CPeripheral
    {
        public SensirionSHT3x(string model = "SHT31", string vendor = "Sensirion") : base(model, vendor, "driver_compatible")
        {
            SetEnvironment(25, 50);
        }

        public void Write(byte[] data)
        {
            if(data == null || data.Length < 2) return;
            command = (ushort)((data[0] << 8) | data[1]);
            if(command == 0x30A2) Reset();
        }

        public byte[] Read(int count = 1)
        {
            var frame = new byte[6];
            var rawT = (ushort)Math.Max(0, Math.Min(65535, (Temperature + 45.0) * 65535.0 / 175.0));
            var rawH = (ushort)Math.Max(0, Math.Min(65535, Humidity * 65535.0 / 100.0));
            frame[0] = (byte)(rawT >> 8); frame[1] = (byte)rawT; frame[2] = Crc8(frame, 0);
            frame[3] = (byte)(rawH >> 8); frame[4] = (byte)rawH; frame[5] = Crc8(frame, 3);
            var result = new byte[Math.Max(0, count)];
            Array.Copy(frame, result, Math.Min(frame.Length, result.Length));
            IRQ.Unset();
            return result;
        }

        public void FinishTransmission() { }
        public void SetEnvironment(double temperature, double humidity) { Temperature = temperature; Humidity = humidity; IRQ.Set(); }
        public double Temperature { get; private set; }
        public double Humidity { get; private set; }

        private static byte Crc8(byte[] data, int offset)
        {
            byte crc = 0xFF;
            for(var i = 0; i < 2; i++)
            {
                crc ^= data[offset + i];
                for(var b = 0; b < 8; b++) crc = (byte)((crc & 0x80) != 0 ? (crc << 1) ^ 0x31 : crc << 1);
            }
            return crc;
        }
        private ushort command;
    }

    public class SensirionSHT4x : SensirionSHT3x
    {
        public SensirionSHT4x(string model = "SHT40", string vendor = "Sensirion") : base(model, vendor) { }
    }

    public class InvenSenseMPU6050 : ProfiledI2CSensor
    {
        public InvenSenseMPU6050(string model = "MPU6050", string vendor = "TDK InvenSense") : base(model, vendor, "driver_compatible")
        {
            WriteRegister(0x75, 0x68);
            DefineMotionChannels(0x3B);
            SetMotion(0, 0, 9.80665, 0, 0, 0, 25);
        }
        protected void DefineMotionChannels(int offset)
        {
            DefineChannel("accel_x", "m_s2", 9.80665 / 16384.0, offset + 0, 2, true, true);
            DefineChannel("accel_y", "m_s2", 9.80665 / 16384.0, offset + 2, 2, true, true);
            DefineChannel("accel_z", "m_s2", 9.80665 / 16384.0, offset + 4, 2, true, true);
            DefineChannel("temperature", "C", 1.0 / 340.0, offset + 6, 2, true, true);
            DefineChannel("gyro_x", "deg_s", 1.0 / 131.0, offset + 8, 2, true, true);
            DefineChannel("gyro_y", "deg_s", 1.0 / 131.0, offset + 10, 2, true, true);
            DefineChannel("gyro_z", "deg_s", 1.0 / 131.0, offset + 12, 2, true, true);
        }
        public void SetMotion(double ax, double ay, double az, double gx, double gy, double gz, double temperature)
        {
            SetChannelValue("accel_x", ax); SetChannelValue("accel_y", ay); SetChannelValue("accel_z", az);
            SetChannelValue("gyro_x", gx); SetChannelValue("gyro_y", gy); SetChannelValue("gyro_z", gz);
            var rawTemperature = (short)Math.Round((temperature - 36.53) * 340.0);
            WriteRegister16(0x41, unchecked((ushort)rawTemperature), true);
        }
    }

    public class STLIS3DH : ProfiledI2CSensor
    {
        public STLIS3DH(string model = "LIS3DH", string vendor = "STMicroelectronics") : base(model, vendor, "driver_compatible")
        {
            WriteRegister(0x0F, 0x33);
            DefineChannel("accel_x", "m_s2", 9.80665 / 16384.0, 0x28, 2, true, false);
            DefineChannel("accel_y", "m_s2", 9.80665 / 16384.0, 0x2A, 2, true, false);
            DefineChannel("accel_z", "m_s2", 9.80665 / 16384.0, 0x2C, 2, true, false);
            SetChannelValue("accel_z", 9.80665);
        }
    }

    public class STLSM6DSOX : ProfiledI2CSensor
    {
        public STLSM6DSOX(string model = "LSM6DSOX", string vendor = "STMicroelectronics") : base(model, vendor, "driver_compatible")
        {
            WriteRegister(0x0F, 0x6C);
            DefineChannel("gyro_x", "deg_s", 0.00875, 0x22, 2, true, false);
            DefineChannel("gyro_y", "deg_s", 0.00875, 0x24, 2, true, false);
            DefineChannel("gyro_z", "deg_s", 0.00875, 0x26, 2, true, false);
            DefineChannel("accel_x", "m_s2", 0.000598, 0x28, 2, true, false);
            DefineChannel("accel_y", "m_s2", 0.000598, 0x2A, 2, true, false);
            DefineChannel("accel_z", "m_s2", 0.000598, 0x2C, 2, true, false);
            SetChannelValue("accel_z", 9.80665);
        }
    }

    public class BoschBNO055 : ProfiledI2CSensor
    {
        public BoschBNO055(string model = "BNO055", string vendor = "Bosch") : base(model, vendor, "driver_compatible")
        {
            WriteRegister(0x00, 0xA0); WriteRegister(0x01, 0xFB); WriteRegister(0x02, 0x32);
            DefineChannel("euler_heading", "degree", 1.0 / 16.0, 0x1A, 2, true, false);
            DefineChannel("euler_roll", "degree", 1.0 / 16.0, 0x1C, 2, true, false);
            DefineChannel("euler_pitch", "degree", 1.0 / 16.0, 0x1E, 2, true, false);
            WriteRegister(0x35, 0xFF);
        }
    }

    public class RohmBH1750 : ExternalComponentBase, II2CPeripheral
    {
        public RohmBH1750(string model = "BH1750", string vendor = "ROHM") : base(model, vendor, "driver_compatible") { SetLux(100); }
        public void Write(byte[] data) { if(data != null && data.Length > 0) command = data[0]; }
        public byte[] Read(int count = 1)
        {
            var raw = (ushort)Math.Max(0, Math.Min(65535, Lux * 1.2));
            var frame = new byte[] {(byte)(raw >> 8), (byte)raw};
            var result = new byte[Math.Max(0, count)]; Array.Copy(frame, result, Math.Min(frame.Length, result.Length)); IRQ.Unset(); return result;
        }
        public void FinishTransmission() { }
        public void SetLux(double value) { Lux = Math.Max(0, value); IRQ.Set(); }
        public double Lux { get; private set; }
        private byte command;
    }

    public class AMS_TSL2591 : ProfiledI2CSensor
    {
        public AMS_TSL2591(string model = "TSL2591", string vendor = "ams OSRAM") : base(model, vendor, "driver_compatible")
        {
            WriteRegister(0x12, 0x50); DefineChannel("channel0", "count", 1, 0x14, 2, false, false); DefineChannel("channel1", "count", 1, 0x16, 2, false, false);
            SetLight(1000, 100);
        }
        public void SetLight(double visible, double infrared) { SetChannelValue("channel0", visible); SetChannelValue("channel1", infrared); }
    }

    public class BroadcomAPDS9960 : ProfiledI2CSensor
    {
        public BroadcomAPDS9960(string model = "APDS9960", string vendor = "Broadcom") : base(model, vendor, "driver_compatible")
        {
            WriteRegister(0x92, 0xAB); DefineChannel("proximity", "count", 1, 0x9C, 1, false, true); DefineChannel("clear", "count", 1, 0x94, 2, false, false);
        }
    }

    public class STVL53L0X : ProfiledI2CSensor
    {
        public STVL53L0X(string model = "VL53L0X", string vendor = "STMicroelectronics") : base(model, vendor, "driver_compatible")
        {
            WriteRegister(0xC0, 0xEE); WriteRegister(0xC1, 0xAA); DefineChannel("distance", "mm", 1, 0x1E, 2, false, true); SetDistance(500);
        }
        public void SetDistance(double millimeters) { SetChannelValue("distance", millimeters); WriteRegister(0x14, 0x01); }
    }

    public class TI_INA219 : ProfiledI2CSensor
    {
        public TI_INA219(string model = "INA219", string vendor = "Texas Instruments") : base(model, vendor, "driver_compatible")
        {
            WriteRegister16(0x00, 0x399F, true); DefineChannel("voltage", "V", 0.004, 0x04, 2, false, true); DefineChannel("current", "A", 0.001, 0x02, 2, true, true); DefineChannel("power", "W", 0.02, 0x03, 2, false, true);
        }
    }

    public class TI_INA226 : ProfiledI2CSensor
    {
        public TI_INA226(string model = "INA226", string vendor = "Texas Instruments") : base(model, vendor, "driver_compatible")
        {
            WriteRegister16(0x00, 0x4127, true); WriteRegister16(0xFE, 0x5449, true); WriteRegister16(0xFF, 0x2260, true);
            DefineChannel("voltage", "V", 0.00125, 0x02, 2, false, true); DefineChannel("current", "A", 0.001, 0x04, 2, true, true); DefineChannel("power", "W", 0.025, 0x03, 2, false, true);
        }
    }

    public class TI_ADS1115 : ProfiledI2CSensor
    {
        public TI_ADS1115(string model = "ADS1115", string vendor = "Texas Instruments") : base(model, vendor, "driver_compatible")
        {
            DefineChannel("voltage", "V", 0.000125, 0x00, 2, true, true); WriteRegister16(0x01, 0x8583, true); WriteRegister16(0x02, 0x8000, true); WriteRegister16(0x03, 0x7FFF, true);
        }
    }

    public class MicrochipMCP9808 : ProfiledI2CSensor
    {
        public MicrochipMCP9808(string model = "MCP9808", string vendor = "Microchip") : base(model, vendor, "driver_compatible")
        {
            WriteRegister16(0x06, 0x0054, true); WriteRegister16(0x07, 0x0400, true); DefineChannel("temperature", "C", 0.0625, 0x05, 2, true, true); SetChannelValue("temperature", 25);
        }
    }

    public class AMS_CCS811 : ProfiledI2CSensor
    {
        public AMS_CCS811(string model = "CCS811", string vendor = "ams OSRAM") : base(model, vendor, "driver_compatible")
        {
            WriteRegister(0x20, 0x81); WriteRegister(0x00, 0x10); DefineChannel("co2", "ppm", 1, 0x02, 2, false, true); DefineChannel("tvoc", "ppb", 1, 0x04, 2, false, true); SetAirQuality(400, 0);
        }
        public void SetAirQuality(double eco2, double tvoc) { SetChannelValue("co2", eco2); SetChannelValue("tvoc", tvoc); WriteRegister(0x00, 0x18); }
    }

    public class SensirionSGP30 : ProfiledI2CSensor
    {
        public SensirionSGP30(string model = "SGP30", string vendor = "Sensirion") : base(model, vendor, "driver_compatible")
        {
            DefineChannel("co2", "ppm", 1, 0x00, 2, false, true); DefineChannel("tvoc", "ppb", 1, 0x02, 2, false, true); SetChannelValue("co2", 400);
        }
    }

    public class SensirionSCD4x : ProfiledI2CSensor
    {
        public SensirionSCD4x(string model = "SCD41", string vendor = "Sensirion") : base(model, vendor, "driver_compatible")
        {
            DefineChannel("co2", "ppm", 1, 0x00, 2, false, true); DefineChannel("temperature", "C", 0.01, 0x03, 2, true, true); DefineChannel("humidity", "percent", 0.01, 0x06, 2, false, true);
            SetChannelValue("co2", 400); SetChannelValue("temperature", 25); SetChannelValue("humidity", 50);
        }
    }

    public class AMS_AS5600 : ProfiledI2CSensor
    {
        public AMS_AS5600(string model = "AS5600", string vendor = "ams OSRAM") : base(model, vendor, "driver_compatible")
        {
            WriteRegister(0x0B, 0x20); DefineChannel("angle", "degree", 360.0 / 4096.0, 0x0E, 2, false, true);
        }
    }

    public class NXP_MPR121 : ProfiledI2CSensor
    {
        public NXP_MPR121(string model = "MPR121", string vendor = "NXP") : base(model, vendor, "driver_compatible")
        {
            DefineChannel("touch", "mask", 1, 0x00, 2, false, false);
        }
        public void SetTouchMask(ushort mask) { WriteRegister16(0x00, mask, false); IRQ.Set(mask != 0); }
    }

    public class MaximMAX30102 : ProfiledI2CSensor
    {
        public MaximMAX30102(string model = "MAX30102", string vendor = "Analog Devices") : base(model, vendor, "driver_compatible")
        {
            WriteRegister(0xFF, 0x15); DefineChannel("red", "count", 1, 0x07, 3, false, true); DefineChannel("ir", "count", 1, 0x0A, 3, false, true);
        }
    }

    public class MelexisMLX90614 : ProfiledI2CSensor
    {
        public MelexisMLX90614(string model = "MLX90614", string vendor = "Melexis") : base(model, vendor, "driver_compatible")
        {
            DefineChannel("ambient_temperature", "C", 0.02, 0x06, 2, false, false); DefineChannel("object_temperature", "C", 0.02, 0x07, 2, false, false);
            SetChannelValue("ambient_temperature", 25 + 273.15); SetChannelValue("object_temperature", 25 + 273.15);
        }
    }

    public class DS18B20Sensor : ExternalComponentBase
    {
        public DS18B20Sensor(string model = "DS18B20", string vendor = "Analog Devices") : base(model, vendor, "driver_compatible") { SetTemperature(25); }
        public void SetTemperature(double celsius) { Temperature = celsius; IRQ.Set(); }
        public byte[] ReadScratchpad()
        {
            var raw = (short)Math.Round(Temperature * 16.0); var result = new byte[] {(byte)raw, (byte)(raw >> 8), 0x4B, 0x46, 0x7F, 0xFF, 0x0C, 0x10, 0}; result[8] = Crc8(result); IRQ.Unset(); return result;
        }
        public double Temperature { get; private set; }
        private static byte Crc8(byte[] data) { byte crc=0; for(var i=0;i<8;i++){var value=data[i]; for(var b=0;b<8;b++){var mix=(crc^value)&1; crc>>=1; if(mix!=0)crc^=0x8C; value>>=1;}} return crc; }
    }

    public class MaximMAX31855 : ExternalComponentBase, ISPIPeripheral
    {
        public MaximMAX31855(string model = "MAX31855", string vendor = "Analog Devices") : base(model, vendor, "driver_compatible") { SetTemperature(25, 25); }
        public byte Transmit(byte data) { var result=frame[index++ % 4]; return result; }
        public void FinishTransmission() { index=0; }
        public void SetTemperature(double thermocouple, double internalTemperature)
        {
            var tc=(int)Math.Round(thermocouple/0.25); var it=(int)Math.Round(internalTemperature/0.0625); uint raw=(uint)((tc & 0x3FFF)<<18)|(uint)((it&0xFFF)<<4); frame[0]=(byte)(raw>>24); frame[1]=(byte)(raw>>16); frame[2]=(byte)(raw>>8); frame[3]=(byte)raw; IRQ.Set();
        }
        private readonly byte[] frame=new byte[4]; private int index;
    }

    public class MaximMAX31865 : ProfiledSPISensor
    {
        public MaximMAX31865(string model = "MAX31865", string vendor = "Analog Devices") : base(model, vendor, "driver_compatible")
        {
            DefineChannel("rtd", "ohm", 0.01, 0x01, 2, false, true); SetChannelValue("rtd", 100);
        }
    }

    public class PlantowerPMS5003 : ProfiledUARTSensor
    {
        public PlantowerPMS5003(string model = "PMS5003", string vendor = "Plantower") : base(model, vendor, "driver_compatible", 9600) { }
        public void EmitMeasurement(ushort pm1, ushort pm25, ushort pm10)
        {
            var frame=new byte[32]; frame[0]=0x42; frame[1]=0x4D; frame[2]=0; frame[3]=28; frame[10]=(byte)(pm1>>8); frame[11]=(byte)pm1; frame[12]=(byte)(pm25>>8); frame[13]=(byte)pm25; frame[14]=(byte)(pm10>>8); frame[15]=(byte)pm10; ushort sum=0; for(var i=0;i<30;i++)sum+=frame[i]; frame[30]=(byte)(sum>>8); frame[31]=(byte)sum; EmitFrame(frame);
        }
    }

    public class UBloxNEO6M : ProfiledUARTSensor
    {
        public UBloxNEO6M(string model = "NEO6M", string vendor = "u-blox") : base(model, vendor, "driver_compatible", 9600) { }
        public void EmitPosition(double latitude, double longitude, double altitude)
        {
            var body=$"GPGGA,120000.00,{ToNmea(latitude,true)},{(latitude>=0?'N':'S')},{ToNmea(longitude,false)},{(longitude>=0?'E':'W')},1,08,0.9,{altitude.ToString("0.0",CultureInfo.InvariantCulture)},M,0.0,M,,";
            byte checksum=0; foreach(var c in body)checksum^=(byte)c; EmitText("$"+body+"*"+checksum.ToString("X2")+"\r\n");
        }
        private static string ToNmea(double value, bool latitude) { value=Math.Abs(value); var deg=(int)value; var minutes=(value-deg)*60; return deg.ToString(latitude?"00":"000",CultureInfo.InvariantCulture)+minutes.ToString("00.0000",CultureInfo.InvariantCulture); }
    }

    public class HCSR04Sensor : ExternalComponentBase, IGPIOReceiver
    {
        public HCSR04Sensor(string model = "HC_SR04", string vendor = "Various") : base(model, vendor, "driver_compatible") { Echo=new GPIO(); DistanceMillimeters=500; }
        public void OnGPIO(int number, bool value) { if(number==0 && value && !lastTrigger){Echo.Set(); Echo.Unset(); IRQ.Set();} lastTrigger=value; }
        public void SetDistance(double millimeters) { DistanceMillimeters=Math.Max(20,Math.Min(4000,millimeters)); }
        public double GetEchoPulseMicroseconds() => DistanceMillimeters*2.0/0.343;
        public GPIO Echo { get; }
        public double DistanceMillimeters { get; private set; }
        private bool lastTrigger;
    }

    public class HX711Sensor : ExternalComponentBase, IGPIOReceiver
    {
        public HX711Sensor(string model = "HX711", string vendor = "Avia Semiconductor") : base(model, vendor, "driver_compatible") { Data=new GPIO(); SetRawValue(0); }
        public void OnGPIO(int number, bool value)
        {
            if(number!=0) return; if(value && !clock){bitIndex=(bitIndex+1)%25; var bit=bitIndex<24 && ((raw>>(23-bitIndex))&1)!=0; Data.Set(bit);} clock=value;
        }
        public void SetRawValue(int value) { raw=value&0xFFFFFF; bitIndex=-1; Data.Unset(); IRQ.Set(); }
        public GPIO Data { get; }
        private int raw; private int bitIndex; private bool clock;
    }
}
