// Copyright (c) 2026
// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

using Antmicro.Renode.Core;
using Antmicro.Renode.Peripherals.I2C;
using Antmicro.Renode.Peripherals.SPI;
using Antmicro.Renode.Peripherals.UART;

namespace Antmicro.Renode.Peripherals.ExternalComponents
{
    public abstract class ExternalComponentBase : IPeripheral
    {
        protected ExternalComponentBase(string model, string vendor, string fidelity)
        {
            Model = model;
            Vendor = vendor;
            Fidelity = fidelity;
            IRQ = new GPIO();
        }

        public virtual void Reset()
        {
            Faulted = false;
            IRQ.Unset();
        }

        public void SetFault(bool value)
        {
            Faulted = value;
            IRQ.Set(value);
        }

        public string Model { get; }
        public string Vendor { get; }
        public string Fidelity { get; }
        public bool Faulted { get; private set; }
        public GPIO IRQ { get; }
    }

    public class ProfiledI2CDevice : ExternalComponentBase, II2CPeripheral
    {
        public ProfiledI2CDevice(string model, string vendor = "Various", string fidelity = "profiled_behavioral", int registerCount = 256)
            : base(model, vendor, fidelity)
        {
            if(registerCount <= 0 || registerCount > 65536)
            {
                throw new ArgumentOutOfRangeException(nameof(registerCount));
            }
            registers = new byte[registerCount];
        }

        public virtual void Write(byte[] data)
        {
            if(data == null || data.Length == 0)
            {
                return;
            }

            pointer = data[0];
            for(var i = 1; i < data.Length; i++)
            {
                WriteRegister(pointer, data[i]);
                pointer = (pointer + 1) % registers.Length;
            }
        }

        public virtual byte[] Read(int count = 1)
        {
            if(count < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(count));
            }
            var result = new byte[count];
            for(var i = 0; i < count; i++)
            {
                result[i] = ReadRegister(pointer);
                pointer = (pointer + 1) % registers.Length;
            }
            return result;
        }

        public virtual void FinishTransmission()
        {
        }

        public byte ReadRegister(long offset)
        {
            return offset >= 0 && offset < registers.Length ? registers[(int)offset] : (byte)0;
        }

        public void WriteRegister(long offset, byte value)
        {
            if(offset >= 0 && offset < registers.Length)
            {
                registers[(int)offset] = value;
            }
        }

        public void WriteRegister16(long offset, ushort value, bool bigEndian = true)
        {
            if(bigEndian)
            {
                WriteRegister(offset, (byte)(value >> 8));
                WriteRegister(offset + 1, (byte)value);
            }
            else
            {
                WriteRegister(offset, (byte)value);
                WriteRegister(offset + 1, (byte)(value >> 8));
            }
        }

        public void WriteRegister32(long offset, uint value, bool bigEndian = true)
        {
            for(var i = 0; i < 4; i++)
            {
                var shift = bigEndian ? (3 - i) * 8 : i * 8;
                WriteRegister(offset + i, (byte)(value >> shift));
            }
        }

        public override void Reset()
        {
            base.Reset();
            Array.Clear(registers, 0, registers.Length);
            pointer = 0;
        }

        protected byte[] Registers => registers;
        protected int Pointer { get => pointer; set => pointer = Math.Max(0, value % registers.Length); }

        private readonly byte[] registers;
        private int pointer;
    }

    public class ProfiledSPIDevice : ExternalComponentBase, ISPIPeripheral
    {
        public ProfiledSPIDevice(string model, string vendor = "Various", string fidelity = "profiled_behavioral", int registerCount = 256, byte readMask = 0x80, byte addressMask = 0x7F)
            : base(model, vendor, fidelity)
        {
            registers = new byte[registerCount];
            this.readMask = readMask;
            this.addressMask = addressMask;
        }

        public virtual byte Transmit(byte data)
        {
            if(!selected)
            {
                selected = true;
                isRead = (data & readMask) != 0;
                pointer = data & addressMask;
                return 0;
            }

            if(isRead)
            {
                var result = ReadRegister(pointer);
                pointer = (pointer + 1) % registers.Length;
                return result;
            }

            WriteRegister(pointer, data);
            pointer = (pointer + 1) % registers.Length;
            return 0;
        }

        public virtual void FinishTransmission()
        {
            selected = false;
            isRead = false;
            pointer = 0;
        }

        public byte ReadRegister(long offset)
        {
            return offset >= 0 && offset < registers.Length ? registers[(int)offset] : (byte)0;
        }

        public void WriteRegister(long offset, byte value)
        {
            if(offset >= 0 && offset < registers.Length)
            {
                registers[(int)offset] = value;
            }
        }

        public void WriteRegister16(long offset, ushort value, bool bigEndian = true)
        {
            if(bigEndian)
            {
                WriteRegister(offset, (byte)(value >> 8));
                WriteRegister(offset + 1, (byte)value);
            }
            else
            {
                WriteRegister(offset, (byte)value);
                WriteRegister(offset + 1, (byte)(value >> 8));
            }
        }

        public override void Reset()
        {
            base.Reset();
            Array.Clear(registers, 0, registers.Length);
            FinishTransmission();
        }

        protected byte[] Registers => registers;

        private readonly byte[] registers;
        private readonly byte readMask;
        private readonly byte addressMask;
        private bool selected;
        private bool isRead;
        private int pointer;
    }

    public class ProfiledUARTDevice : ExternalComponentBase, IUART
    {
        public ProfiledUARTDevice(string model, string vendor = "Various", string fidelity = "profiled_behavioral", uint baudRate = 9600)
            : base(model, vendor, fidelity)
        {
            BaudRate = baudRate;
        }

        public void WriteChar(byte value)
        {
            receivedFromHost.Enqueue(value);
            OnHostByte(value);
        }

        public bool TryDequeueHostByte(out byte value)
        {
            if(receivedFromHost.Count == 0)
            {
                value = 0;
                return false;
            }
            value = receivedFromHost.Dequeue();
            return true;
        }

        public void EmitByte(byte value)
        {
            CharReceived?.Invoke(value);
        }

        public void EmitFrame(byte[] frame)
        {
            if(frame == null)
            {
                return;
            }
            foreach(var value in frame)
            {
                EmitByte(value);
            }
        }

        public void EmitText(string text)
        {
            EmitFrame(System.Text.Encoding.ASCII.GetBytes(text ?? string.Empty));
        }

        public override void Reset()
        {
            base.Reset();
            receivedFromHost.Clear();
        }

        protected virtual void OnHostByte(byte value)
        {
        }

        public uint BaudRate { get; }
        public Bits StopBits => Bits.One;
        public Parity ParityBit => Parity.None;

        [field: NonSerialized]
        public event Action<byte> CharReceived;

        private readonly Queue<byte> receivedFromHost = new Queue<byte>();
    }

    public class ProfiledGPIODevice : ExternalComponentBase, IGPIOReceiver
    {
        public ProfiledGPIODevice(string model, string vendor = "Various", string fidelity = "profiled_behavioral", int inputs = 8)
            : base(model, vendor, fidelity)
        {
            states = new bool[Math.Max(1, inputs)];
            Output = new GPIO();
        }

        public virtual void OnGPIO(int number, bool value)
        {
            if(number < 0 || number >= states.Length)
            {
                throw new ArgumentOutOfRangeException(nameof(number));
            }
            states[number] = value;
        }

        public bool GetInput(int number)
        {
            return number >= 0 && number < states.Length && states[number];
        }

        public override void Reset()
        {
            base.Reset();
            Array.Clear(states, 0, states.Length);
            Output.Unset();
        }

        public GPIO Output { get; }
        protected bool[] Inputs => states;

        private readonly bool[] states;
    }

    public sealed class SensorChannel
    {
        public SensorChannel(string name, string unit, double resolution, int registerOffset, int width = 2, bool signed = true, bool bigEndian = true)
        {
            Name = name;
            Unit = unit;
            Resolution = resolution == 0 ? 1 : resolution;
            RegisterOffset = registerOffset;
            Width = Math.Max(1, Math.Min(4, width));
            Signed = signed;
            BigEndian = bigEndian;
        }

        public string Name { get; }
        public string Unit { get; }
        public double Resolution { get; }
        public int RegisterOffset { get; }
        public int Width { get; }
        public bool Signed { get; }
        public bool BigEndian { get; }
    }

    public static class ExternalComponentEncoding
    {
        public static void Encode(byte[] registers, SensorChannel channel, double value)
        {
            var rawDouble = Math.Round(value / channel.Resolution);
            var bits = channel.Width * 8;
            long minimum = channel.Signed ? -(1L << (bits - 1)) : 0;
            long maximum = channel.Signed ? (1L << (bits - 1)) - 1 : (bits == 32 ? uint.MaxValue : (1L << bits) - 1);
            var raw = (long)Math.Max(minimum, Math.Min(maximum, rawDouble));
            var unsigned = unchecked((ulong)raw);
            for(var i = 0; i < channel.Width; i++)
            {
                var shift = channel.BigEndian ? (channel.Width - 1 - i) * 8 : i * 8;
                var index = channel.RegisterOffset + i;
                if(index >= 0 && index < registers.Length)
                {
                    registers[index] = (byte)(unsigned >> shift);
                }
            }
        }

        public static uint Fnv1a(byte[] data)
        {
            var hash = 2166136261u;
            foreach(var value in data)
            {
                hash ^= value;
                hash *= 16777619u;
            }
            return hash;
        }
    }
}
