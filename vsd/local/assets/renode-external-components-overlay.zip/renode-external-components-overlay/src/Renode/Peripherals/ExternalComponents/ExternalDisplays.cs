// Copyright (c) 2026
// SPDX-License-Identifier: MIT

using System;
using System.IO;

using Antmicro.Renode.Core;
using Antmicro.Renode.Peripherals.I2C;
using Antmicro.Renode.Peripherals.SPI;

namespace Antmicro.Renode.Peripherals.ExternalComponents.Displays
{
    public abstract class FramebufferDisplay : ExternalComponentBase
    {
        protected FramebufferDisplay(string model, string vendor, string fidelity, int width, int height, int bitsPerPixel)
            : base(model, vendor, fidelity)
        {
            Width = Math.Max(1, width);
            Height = Math.Max(1, height);
            BitsPerPixel = Math.Max(1, bitsPerPixel);
            pixels = new uint[Width * Height];
        }

        public void SetPixel(int x, int y, uint rgb)
        {
            if(x < 0 || y < 0 || x >= Width || y >= Height)
            {
                return;
            }
            pixels[y * Width + x] = rgb & 0xFFFFFFu;
        }

        public uint GetPixel(int x, int y)
        {
            if(x < 0 || y < 0 || x >= Width || y >= Height)
            {
                return 0;
            }
            return pixels[y * Width + x];
        }

        public void Clear(uint rgb = 0)
        {
            for(var i = 0; i < pixels.Length; i++)
            {
                pixels[i] = rgb & 0xFFFFFFu;
            }
        }

        public uint GetFrameChecksum()
        {
            var bytes = new byte[pixels.Length * 3];
            for(var i = 0; i < pixels.Length; i++)
            {
                bytes[i * 3] = (byte)(pixels[i] >> 16);
                bytes[i * 3 + 1] = (byte)(pixels[i] >> 8);
                bytes[i * 3 + 2] = (byte)pixels[i];
            }
            return ExternalComponentEncoding.Fnv1a(bytes);
        }

        public void ExportPpm(string path)
        {
            using(var stream = File.Create(path))
            using(var writer = new BinaryWriter(stream))
            {
                writer.Write(System.Text.Encoding.ASCII.GetBytes($"P6\n{Width} {Height}\n255\n"));
                foreach(var pixel in pixels)
                {
                    writer.Write((byte)(pixel >> 16));
                    writer.Write((byte)(pixel >> 8));
                    writer.Write((byte)pixel);
                }
            }
        }

        public override void Reset()
        {
            base.Reset();
            Clear();
            DisplayEnabled = false;
            Inverted = false;
        }

        public int Width { get; }
        public int Height { get; }
        public int BitsPerPixel { get; }
        public bool DisplayEnabled { get; protected set; }
        public bool Inverted { get; protected set; }

        protected uint[] Pixels => pixels;
        private readonly uint[] pixels;
    }

    public class GenericI2CDisplay : FramebufferDisplay, II2CPeripheral
    {
        public GenericI2CDisplay(string model, string vendor, int width, int height, int bitsPerPixel, string fidelity = "profiled_behavioral")
            : base(model, vendor, fidelity, width, height, bitsPerPixel)
        {
        }

        public virtual void Write(byte[] data)
        {
            if(data == null || data.Length == 0)
            {
                return;
            }
            var first = data[0];
            var start = 1;
            var dataMode = first == 0x40 || first == 0xC0;
            if(first != 0x00 && first != 0x40 && first != 0x80 && first != 0xC0)
            {
                dataMode = true;
                start = 0;
            }
            for(var i = start; i < data.Length; i++)
            {
                if(dataMode)
                {
                    ConsumeData(data[i]);
                }
                else
                {
                    ConsumeCommand(data[i]);
                }
            }
        }

        public virtual byte[] Read(int count = 1)
        {
            var result = new byte[Math.Max(0, count)];
            if(result.Length > 0)
            {
                result[0] = (byte)(DisplayEnabled ? 1 : 0);
            }
            return result;
        }

        public virtual void FinishTransmission()
        {
        }

        protected virtual void ConsumeCommand(byte value)
        {
            switch(value)
            {
                case 0xAE: DisplayEnabled = false; break;
                case 0xAF: DisplayEnabled = true; break;
                case 0xA6: Inverted = false; break;
                case 0xA7: Inverted = true; break;
                default: LastCommand = value; break;
            }
        }

        protected virtual void ConsumeData(byte value)
        {
            var x = cursor % Width;
            var y = (cursor / Width) % Height;
            if(BitsPerPixel <= 1)
            {
                for(var bit = 0; bit < 8; bit++)
                {
                    var yy = (y + bit) % Height;
                    SetPixel(x, yy, (value & (1 << bit)) != 0 ? 0xFFFFFFu : 0u);
                }
            }
            else
            {
                SetPixel(x, y, value == 0 ? 0u : 0xFFFFFFu);
            }
            cursor = (cursor + 1) % (Width * Height);
        }

        protected byte LastCommand { get; set; }
        protected int Cursor { get => cursor; set => cursor = Math.Max(0, value % (Width * Height)); }

        private int cursor;
    }

    public class GenericSPIDisplay : FramebufferDisplay, ISPIPeripheral, IGPIOReceiver
    {
        public GenericSPIDisplay(string model, string vendor, int width, int height, int bitsPerPixel, string fidelity = "profiled_behavioral")
            : base(model, vendor, fidelity, width, height, bitsPerPixel)
        {
            Busy = new GPIO();
        }

        public virtual byte Transmit(byte data)
        {
            if(dataCommand)
            {
                ConsumeData(data);
            }
            else
            {
                ConsumeCommand(data);
            }
            return 0;
        }

        public virtual void FinishTransmission()
        {
            parameterIndex = 0;
        }

        public virtual void OnGPIO(int number, bool value)
        {
            switch(number)
            {
                case 0:
                    dataCommand = value;
                    break;
                case 1:
                    if(!value)
                    {
                        Reset();
                    }
                    break;
                default:
                    break;
            }
        }

        protected virtual void ConsumeCommand(byte value)
        {
            LastCommand = value;
            parameterIndex = 0;
            if(value == 0x01)
            {
                Reset();
            }
            else if(value == 0x28)
            {
                DisplayEnabled = false;
            }
            else if(value == 0x29)
            {
                DisplayEnabled = true;
            }
            else if(value == 0x20)
            {
                Inverted = false;
            }
            else if(value == 0x21)
            {
                Inverted = true;
            }
        }

        protected virtual void ConsumeData(byte value)
        {
            if(LastCommand == 0x2A)
            {
                columnParameters[parameterIndex++ % 4] = value;
                if(parameterIndex >= 4)
                {
                    xStart = (columnParameters[0] << 8) | columnParameters[1];
                    xEnd = (columnParameters[2] << 8) | columnParameters[3];
                }
                return;
            }
            if(LastCommand == 0x2B)
            {
                rowParameters[parameterIndex++ % 4] = value;
                if(parameterIndex >= 4)
                {
                    yStart = (rowParameters[0] << 8) | rowParameters[1];
                    yEnd = (rowParameters[2] << 8) | rowParameters[3];
                }
                return;
            }
            if(LastCommand == 0x2C || LastCommand == 0x3C || LastCommand == 0x24)
            {
                pixelBytes[pixelByteIndex++] = value;
                var required = BitsPerPixel <= 8 ? 1 : BitsPerPixel <= 16 ? 2 : 3;
                if(pixelByteIndex >= required)
                {
                    uint rgb;
                    if(required == 1)
                    {
                        rgb = value == 0 ? 0u : 0xFFFFFFu;
                    }
                    else if(required == 2)
                    {
                        var raw = (ushort)((pixelBytes[0] << 8) | pixelBytes[1]);
                        rgb = (uint)(((raw >> 11) & 0x1F) * 255 / 31 << 16)
                            | (uint)(((raw >> 5) & 0x3F) * 255 / 63 << 8)
                            | (uint)((raw & 0x1F) * 255 / 31);
                    }
                    else
                    {
                        rgb = (uint)((pixelBytes[0] << 16) | (pixelBytes[1] << 8) | pixelBytes[2]);
                    }
                    SetPixel(currentX, currentY, rgb);
                    AdvanceCursor();
                    pixelByteIndex = 0;
                }
            }
        }

        public override void Reset()
        {
            base.Reset();
            dataCommand = false;
            LastCommand = 0;
            xStart = 0;
            yStart = 0;
            xEnd = Width - 1;
            yEnd = Height - 1;
            currentX = 0;
            currentY = 0;
            pixelByteIndex = 0;
            Busy.Unset();
        }

        public GPIO Busy { get; }
        protected byte LastCommand { get; set; }

        private void AdvanceCursor()
        {
            currentX++;
            if(currentX > Math.Min(Width - 1, xEnd))
            {
                currentX = Math.Max(0, xStart);
                currentY++;
                if(currentY > Math.Min(Height - 1, yEnd))
                {
                    currentY = Math.Max(0, yStart);
                }
            }
        }

        private bool dataCommand;
        private int parameterIndex;
        private readonly byte[] columnParameters = new byte[4];
        private readonly byte[] rowParameters = new byte[4];
        private readonly byte[] pixelBytes = new byte[3];
        private int pixelByteIndex;
        private int xStart;
        private int xEnd;
        private int yStart;
        private int yEnd;
        private int currentX;
        private int currentY;
    }

    public class GenericParallelDisplay : FramebufferDisplay, IGPIOReceiver
    {
        public GenericParallelDisplay(string model, string vendor, int width, int height, int bitsPerPixel, string fidelity = "profiled_behavioral")
            : base(model, vendor, fidelity, width, height, bitsPerPixel)
        {
        }

        public void OnGPIO(int number, bool value)
        {
            if(number >= 0 && number < 8)
            {
                if(value) data |= (byte)(1 << number); else data &= (byte)~(1 << number);
                return;
            }
            if(number == 8 && value)
            {
                SetPixel(cursor % Width, (cursor / Width) % Height, data == 0 ? 0u : 0xFFFFFFu);
                cursor = (cursor + 1) % (Width * Height);
            }
            if(number == 9 && !value)
            {
                Reset();
            }
        }

        private byte data;
        private int cursor;
    }

    public class SSD1306Controller : GenericI2CDisplay
    {
        public SSD1306Controller(string model = "SSD1306", string vendor = "Solomon Systech", int width = 128, int height = 64)
            : base(model, vendor, width, height, 1, "driver_compatible")
        {
        }

        protected override void ConsumeCommand(byte value)
        {
            base.ConsumeCommand(value);
            if(value >= 0xB0 && value <= 0xB7)
            {
                page = value - 0xB0;
                UpdateCursor();
            }
            else if((value & 0xF0) == 0x00)
            {
                column = (column & 0xF0) | (value & 0x0F);
                UpdateCursor();
            }
            else if((value & 0xF0) == 0x10)
            {
                column = (column & 0x0F) | ((value & 0x0F) << 4);
                UpdateCursor();
            }
        }

        protected override void ConsumeData(byte value)
        {
            for(var bit = 0; bit < 8; bit++)
            {
                var y = page * 8 + bit;
                SetPixel(column, y, (value & (1 << bit)) != 0 ? 0xFFFFFFu : 0u);
            }
            column = (column + 1) % Width;
            UpdateCursor();
        }

        private void UpdateCursor()
        {
            Cursor = Math.Min(Height - 1, page * 8) * Width + Math.Min(Width - 1, column);
        }

        private int page;
        private int column;
    }

    public class ST77xxController : GenericSPIDisplay
    {
        public ST77xxController(string model, string vendor, int width, int height, int bitsPerPixel = 16)
            : base(model, vendor, width, height, bitsPerPixel, "driver_compatible")
        {
        }
    }

    public class ILI9341Controller : GenericSPIDisplay
    {
        public ILI9341Controller(string model = "ILI9341", string vendor = "Ilitek", int width = 240, int height = 320, int bitsPerPixel = 16)
            : base(model, vendor, width, height, bitsPerPixel, "driver_compatible")
        {
        }
    }

    public class EpaperController : GenericSPIDisplay
    {
        public EpaperController(string model, string vendor, int width, int height)
            : base(model, vendor, width, height, 1, "driver_compatible")
        {
        }

        protected override void ConsumeCommand(byte value)
        {
            base.ConsumeCommand(value);
            if(value == 0x12)
            {
                Busy.Set();
                Reset();
                Busy.Unset();
            }
            if(value == 0x20)
            {
                Busy.Set();
                DisplayEnabled = true;
                Busy.Unset();
            }
        }
    }

    public class CharacterDisplayController : ExternalComponentBase, II2CPeripheral, IGPIOReceiver
    {
        public CharacterDisplayController(string model, string vendor, int columns, int rows, string fidelity = "profiled_behavioral")
            : base(model, vendor, fidelity)
        {
            Columns = Math.Max(1, columns);
            Rows = Math.Max(1, rows);
            cells = new char[Columns * Rows];
            Reset();
        }

        public void Write(byte[] data)
        {
            if(data == null) return;
            foreach(var value in data)
            {
                WriteData(value);
            }
        }

        public byte[] Read(int count = 1)
        {
            var result = new byte[Math.Max(0, count)];
            for(var i = 0; i < result.Length; i++)
            {
                result[i] = (byte)cells[(cursor + i) % cells.Length];
            }
            return result;
        }

        public void FinishTransmission()
        {
        }

        public void OnGPIO(int number, bool value)
        {
            if(number >= 0 && number < 8)
            {
                if(value) gpioData |= (byte)(1 << number); else gpioData &= (byte)~(1 << number);
            }
            else if(number == 8 && value)
            {
                WriteData(gpioData);
            }
            else if(number == 9 && !value)
            {
                Reset();
            }
        }

        public void WriteData(byte value)
        {
            if(value == 0x01)
            {
                Reset();
                return;
            }
            if((value & 0x80) != 0)
            {
                cursor = value & 0x7F;
                cursor %= cells.Length;
                return;
            }
            cells[cursor] = value >= 0x20 && value < 0x7F ? (char)value : ' ';
            cursor = (cursor + 1) % cells.Length;
        }

        public string GetLine(int row)
        {
            if(row < 0 || row >= Rows) return string.Empty;
            return new string(cells, row * Columns, Columns);
        }

        public override void Reset()
        {
            base.Reset();
            for(var i = 0; i < cells.Length; i++) cells[i] = ' ';
            cursor = 0;
            gpioData = 0;
        }

        public int Columns { get; }
        public int Rows { get; }

        private readonly char[] cells;
        private int cursor;
        private byte gpioData;
    }

    public class HT16K33Controller : ProfiledI2CDevice
    {
        public HT16K33Controller(string model = "HT16K33", string vendor = "Holtek") : base(model, vendor, "driver_compatible", 256)
        {
        }

        public override void Write(byte[] data)
        {
            if(data == null || data.Length == 0) return;
            if(data.Length == 1 && (data[0] & 0xE0) == 0x20)
            {
                OscillatorEnabled = (data[0] & 1) != 0;
                return;
            }
            if(data.Length == 1 && (data[0] & 0xF0) == 0x80)
            {
                DisplayEnabled = (data[0] & 1) != 0;
                return;
            }
            base.Write(data);
        }

        public bool OscillatorEnabled { get; private set; }
        public bool DisplayEnabled { get; private set; }
    }

    public class MAX7219Controller : ProfiledSPIDevice
    {
        public MAX7219Controller(string model = "MAX7219", string vendor = "Analog Devices") : base(model, vendor, "driver_compatible", 32, 0, 0x1F)
        {
        }

        public override byte Transmit(byte data)
        {
            if(!haveAddress)
            {
                address = data;
                haveAddress = true;
            }
            else
            {
                WriteRegister(address, data);
                haveAddress = false;
            }
            return 0;
        }

        public override void FinishTransmission()
        {
            haveAddress = false;
            base.FinishTransmission();
        }

        private bool haveAddress;
        private byte address;
    }

    public class RA8875Controller : GenericSPIDisplay
    {
        public RA8875Controller(string model = "RA8875", string vendor = "RAiO", int width = 800, int height = 480)
            : base(model, vendor, width, height, 16, "driver_compatible")
        {
        }
    }

    public class FT8xxController : GenericSPIDisplay
    {
        public FT8xxController(string model, string vendor, int width, int height)
            : base(model, vendor, width, height, 16, "driver_compatible")
        {
        }
    }

    public class IS31FL3731Controller : ProfiledI2CDevice
    {
        public IS31FL3731Controller(string model = "IS31FL3731", string vendor = "Lumissil") : base(model, vendor, "driver_compatible", 256)
        {
        }

        public byte GetLedPwm(int index)
        {
            return ReadRegister(0x24 + index);
        }
    }
}
