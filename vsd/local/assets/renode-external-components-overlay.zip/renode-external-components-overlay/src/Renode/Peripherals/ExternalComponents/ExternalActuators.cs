// Copyright (c) 2026
// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;

using Antmicro.Renode.Core;

namespace Antmicro.Renode.Peripherals.ExternalComponents.Actuators
{
    public class ProfiledI2CActuator : ProfiledI2CDevice
    {
        public ProfiledI2CActuator(string model, string vendor, string fidelity = "profiled_behavioral") : base(model, vendor, fidelity, 512)
        {
        }

        public void SetCommand(double value)
        {
            Command = value;
            WriteRegister16(0x10, unchecked((ushort)Math.Round(value * 1000)), true);
            IRQ.Set();
        }

        public double Command { get; private set; }
        public bool Enabled { get; protected set; }
    }

    public class ProfiledSPIActuator : ProfiledSPIDevice
    {
        public ProfiledSPIActuator(string model, string vendor, string fidelity = "profiled_behavioral") : base(model, vendor, fidelity, 512)
        {
        }

        public void SetCommand(double value)
        {
            Command = value;
            WriteRegister(0x10, (byte)Math.Max(0, Math.Min(255, Math.Round(value * 255))));
            IRQ.Set();
        }

        public double Command { get; private set; }
    }

    public class ProfiledGPIOActuator : ProfiledGPIODevice
    {
        public ProfiledGPIOActuator(string model, string vendor, string fidelity = "profiled_behavioral") : base(model, vendor, fidelity, 8)
        {
        }

        public override void OnGPIO(int number, bool value)
        {
            base.OnGPIO(number, value);
            switch(number)
            {
                case 0: Enabled = value; break;
                case 1: Direction = value ? 1 : -1; break;
                case 2:
                    if(value && !lastStep && Enabled) Position += Direction * StepSize;
                    lastStep = value;
                    break;
                case 3: Brake = value; break;
            }
        }

        public void SetCommand(double value)
        {
            Command = Math.Max(-1, Math.Min(1, value));
            Velocity = Enabled && !Brake ? Command * MaximumVelocity : 0;
        }

        public bool Enabled { get; private set; }
        public bool Brake { get; private set; }
        public int Direction { get; private set; } = 1;
        public double Position { get; private set; }
        public double Velocity { get; private set; }
        public double Command { get; private set; }
        public double StepSize { get; set; } = 1.8;
        public double MaximumVelocity { get; set; } = 1000;

        private bool lastStep;
    }

    public class ProfiledUARTActuator : ProfiledUARTDevice
    {
        public ProfiledUARTActuator(string model, string vendor, string fidelity = "profiled_behavioral", uint baudRate = 115200) : base(model, vendor, fidelity, baudRate)
        {
        }

        protected override void OnHostByte(byte value)
        {
            packet.Add(value);
            if(value == '\n' || packet.Count >= 32)
            {
                LastPacket = packet.ToArray();
                packet.Clear();
                IRQ.Set();
            }
        }

        public byte[] LastPacket { get; private set; } = Array.Empty<byte>();
        private readonly List<byte> packet = new List<byte>();
    }

    public class PCA9685Controller : ProfiledI2CActuator
    {
        public PCA9685Controller(string model = "PCA9685", string vendor = "NXP") : base(model, vendor, "driver_compatible")
        {
            pwm = new ushort[16];
            WriteRegister(0x00, 0x01);
        }

        public override void Write(byte[] data)
        {
            base.Write(data);
            if(data == null || data.Length < 2) return;
            var start = data[0];
            for(var channel = 0; channel < 16; channel++)
            {
                var offset = 0x06 + channel * 4;
                if(start <= offset + 3 && start + data.Length - 2 >= offset)
                {
                    var offLow = ReadRegister(offset + 2);
                    var offHigh = ReadRegister(offset + 3);
                    pwm[channel] = (ushort)(((offHigh & 0x0F) << 8) | offLow);
                }
            }
            Enabled = (ReadRegister(0x00) & 0x10) == 0;
        }

        public ushort GetPWM(int channel) => channel >= 0 && channel < pwm.Length ? pwm[channel] : (ushort)0;
        public double GetDutyCycle(int channel) => GetPWM(channel) / 4095.0;

        private readonly ushort[] pwm;
    }

    public class TLC5940Controller : ProfiledSPIActuator
    {
        public TLC5940Controller(string model = "TLC5940", string vendor = "Texas Instruments") : base(model, vendor, "driver_compatible")
        {
            channels = new ushort[16];
        }

        public override byte Transmit(byte data)
        {
            shift.Add(data);
            return 0;
        }

        public override void FinishTransmission()
        {
            if(shift.Count >= 24)
            {
                var bit = 0;
                for(var channel = 15; channel >= 0; channel--)
                {
                    ushort value = 0;
                    for(var b = 0; b < 12; b++, bit++)
                    {
                        var byteIndex = bit / 8;
                        var bitIndex = 7 - bit % 8;
                        value = (ushort)((value << 1) | ((shift[byteIndex] >> bitIndex) & 1));
                    }
                    channels[channel] = value;
                }
            }
            shift.Clear();
            base.FinishTransmission();
        }

        public ushort GetChannel(int channel) => channel >= 0 && channel < channels.Length ? channels[channel] : (ushort)0;

        private readonly ushort[] channels;
        private readonly List<byte> shift = new List<byte>();
    }

    public class AddressableLEDStrip : ProfiledSPIDevice
    {
        public AddressableLEDStrip(string model, string vendor, int ledCount = 16, string fidelity = "driver_compatible") : base(model, vendor, fidelity, 16)
        {
            pixels = new uint[Math.Max(1, ledCount)];
        }

        public override byte Transmit(byte data)
        {
            stream.Add(data);
            return 0;
        }

        public override void FinishTransmission()
        {
            var offset = Model.StartsWith("APA102", StringComparison.OrdinalIgnoreCase) ? 4 : 0;
            for(var i = 0; i < pixels.Length && offset + i * 3 + 2 < stream.Count; i++)
            {
                var index = offset + i * 3;
                pixels[i] = (uint)((stream[index] << 16) | (stream[index + 1] << 8) | stream[index + 2]);
            }
            stream.Clear();
            base.FinishTransmission();
        }

        public uint GetPixel(int index) => index >= 0 && index < pixels.Length ? pixels[index] : 0;

        private readonly uint[] pixels;
        private readonly List<byte> stream = new List<byte>();
    }

    public class HBridgeMotorDriver : ProfiledGPIOActuator
    {
        public HBridgeMotorDriver(string model, string vendor) : base(model, vendor, "driver_compatible")
        {
        }
    }

    public class StepDirDriver : ProfiledGPIOActuator
    {
        public StepDirDriver(string model, string vendor, double stepAngle = 1.8) : base(model, vendor, "driver_compatible")
        {
            StepSize = stepAngle;
        }

        public int Microsteps { get; set; } = 1;
    }

    public class TMCStepperController : ProfiledSPIActuator
    {
        public TMCStepperController(string model, string vendor = "Trinamic") : base(model, vendor, "driver_compatible")
        {
        }

        public long Position { get; private set; }
        public int Velocity { get; private set; }


        public void SetTarget(long position, int velocity)
        {
            Position = position;
            Velocity = velocity;
            IRQ.Set();
        }
    }

    public class HobbyServoActuator : ProfiledGPIOActuator
    {
        public HobbyServoActuator(string model = "HOBBY_SERVO_GENERIC", string vendor = "Various") : base(model, vendor, "driver_compatible")
        {
        }

        public void SetPulseWidthMicroseconds(double pulse)
        {
            PulseWidthMicroseconds = Math.Max(500, Math.Min(2500, pulse));
            AngleDegrees = (PulseWidthMicroseconds - 500) * 180.0 / 2000.0;
        }

        public double PulseWidthMicroseconds { get; private set; } = 1500;
        public double AngleDegrees { get; private set; } = 90;
    }

    public class DRV2605Controller : ProfiledI2CActuator
    {
        public DRV2605Controller(string model = "DRV2605L", string vendor = "Texas Instruments") : base(model, vendor, "driver_compatible")
        {
            WriteRegister(0x00, 0xE0);
        }

        public override void Write(byte[] data)
        {
            base.Write(data);
            if(data == null || data.Length < 2) return;
            if(data[0] == 0x0C && (data[1] & 1) != 0)
            {
                Playing = true;
                CurrentEffect = ReadRegister(0x04);
                IRQ.Set();
            }
        }

        public bool Playing { get; private set; }
        public byte CurrentEffect { get; private set; }
    }

    public class CirrusHapticController : ProfiledI2CActuator
    {
        public CirrusHapticController(string model = "CS40L26", string vendor = "Cirrus Logic") : base(model, vendor, "driver_compatible")
        {
        }

        public void PlayWaveform(int waveform)
        {
            Waveform = waveform;
            IRQ.Set();
        }

        public int Waveform { get; private set; }
    }

    public class RelayActuator : ProfiledGPIOActuator
    {
        public RelayActuator(string model = "RELAY_1CH", string vendor = "Various", int channels = 1) : base(model, vendor, "driver_compatible")
        {
            relays = new bool[Math.Max(1, channels)];
        }

        public override void OnGPIO(int number, bool value)
        {
            if(number >= 0 && number < relays.Length) relays[number] = value;
            base.OnGPIO(Math.Min(number, 7), value);
        }

        public bool GetRelay(int channel) => channel >= 0 && channel < relays.Length && relays[channel];

        private readonly bool[] relays;
    }

    public class ULN2003Controller : ProfiledGPIOActuator
    {
        public ULN2003Controller(string model = "ULN2003A", string vendor = "Texas Instruments") : base(model, vendor, "driver_compatible") { }
        public int CoilMask { get { var mask=0; for(var i=0;i<4;i++) if(GetInput(i)) mask|=1<<i; return mask; } }
    }

    public class MCP4725Controller : ProfiledI2CActuator
    {
        public MCP4725Controller(string model = "MCP4725", string vendor = "Microchip") : base(model, vendor, "driver_compatible") { }
        public override void Write(byte[] data)
        {
            base.Write(data);
            if(data == null || data.Length < 2) return;
            var raw = data.Length >= 3 ? ((data[1] & 0x0F) << 8) | data[2] : ((data[0] & 0x0F) << 8) | data[1];
            RawValue = (ushort)raw;
            Voltage = RawValue * ReferenceVoltage / 4095.0;
            IRQ.Set();
        }
        public ushort RawValue { get; private set; }
        public double Voltage { get; private set; }
        public double ReferenceVoltage { get; set; } = 3.3;
    }
}
